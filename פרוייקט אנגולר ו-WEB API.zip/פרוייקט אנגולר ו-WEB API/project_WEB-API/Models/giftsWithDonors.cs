﻿using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models
{
    public class giftsWithDonors
    {
        public int GiftId { get; set; }


        [Required(ErrorMessage = "gift title is required")]
        [StringLength(50)]
        public string GiftTitle { get; set; } = null!;


        [StringLength(50)]
        public string? Description { get; set; }


        [Required]
        [StringLength(50)]
        public string DonorName { get; set; } = null!;


        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ticket cost must be positive number")]
        public int TicketCost { get; set; }


        [Required]
        [StringLength(50)]
        public string CategoryName { get; set; } = null!;


        [Required]
        public int NumBuyers { get; set; } = 0;

        public string? ImageGift { get; set; }

    }
}
