﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models;

public partial class UserGift
{
    public int Id { get; set; }


    [Required]
    public int UserId { get; set; }


    [Required]
    public int GiftId { get; set; }

    public virtual Gift Gift { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
