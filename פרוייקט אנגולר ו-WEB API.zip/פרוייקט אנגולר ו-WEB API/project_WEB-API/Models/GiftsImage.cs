﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models;

public partial class GiftsImage
{
    public int ImageId { get; set; }

    [MaxLength]
    public string ImageName { get; set; } = null!;

    public virtual ICollection<Gift> Gifts { get; set; } = new List<Gift>();
}
