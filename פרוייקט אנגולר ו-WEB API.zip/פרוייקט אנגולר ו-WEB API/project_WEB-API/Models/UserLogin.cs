﻿using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models
{
    public class UserLogin
    {

        [Required]
        [StringLength(256)]
        public string UserName { get; set; } = null!;


        [Required]
        [StringLength(256)]
        public string UserPassword { get; set; } = null!;
    }
}
