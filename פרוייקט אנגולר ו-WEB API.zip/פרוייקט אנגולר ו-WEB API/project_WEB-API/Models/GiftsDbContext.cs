﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace project_WEB_API.Models;

public partial class GiftsDbContext : DbContext
{
    public GiftsDbContext()
    {
    }

    public GiftsDbContext(DbContextOptions<GiftsDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Basket> Baskets { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Donor> Donors { get; set; }

    public virtual DbSet<Gift> Gifts { get; set; }

    public virtual DbSet<GiftsImage> GiftsImages { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserGift> UserGifts { get; set; }

    public virtual DbSet<Winner> Winners { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=srv2\\pupils;initial catalog=328178744_Project_ChineseAuction;Integrated Security=SSPI;Persist Security Info=False;TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Basket>(entity =>
        {
            entity.ToTable("Basket");

            entity.HasOne(d => d.Gift).WithMany(p => p.Baskets)
                .HasForeignKey(d => d.GiftId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Basket_Gifts");

            entity.HasOne(d => d.User).WithMany(p => p.Baskets)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Basket_Users");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.Property(e => e.CategoryName).HasMaxLength(50);
        });

        modelBuilder.Entity<Donor>(entity =>
        {
            entity.Property(e => e.DonorEmail).HasMaxLength(50);
            entity.Property(e => e.DonorName).HasMaxLength(50);
            entity.Property(e => e.DonorPhone).HasMaxLength(50);
        });

        modelBuilder.Entity<Gift>(entity =>
        {
            entity.Property(e => e.Description).HasMaxLength(50);
            entity.Property(e => e.GiftTitle).HasMaxLength(50);

            entity.HasOne(d => d.Category).WithMany(p => p.Gifts)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Gifts_Categories");

            entity.HasOne(d => d.GiftDonor).WithMany(p => p.Gifts)
                .HasForeignKey(d => d.GiftDonorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Gifts_Donors");

            entity.HasOne(d => d.ImageGift).WithMany(p => p.Gifts)
                .HasForeignKey(d => d.ImageGiftId)
                .HasConstraintName("FK_Gifts_GiftsImages");
        });

        modelBuilder.Entity<GiftsImage>(entity =>
        {
            entity.HasKey(e => e.ImageId);

            entity.Property(e => e.ImageName).HasMaxLength(50);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.UserAdress).HasMaxLength(50);
            entity.Property(e => e.UserEmail).HasMaxLength(50);
            entity.Property(e => e.UserName).HasMaxLength(50);
            entity.Property(e => e.UserPassword).HasMaxLength(256);
            entity.Property(e => e.UserPhone).HasMaxLength(50);
            entity.Property(e => e.UserRole).HasMaxLength(50);
        });

        modelBuilder.Entity<UserGift>(entity =>
        {
            entity.HasOne(d => d.Gift).WithMany(p => p.UserGifts)
                .HasForeignKey(d => d.GiftId)
                .HasConstraintName("FK_UserGifts_Gifts");

            entity.HasOne(d => d.User).WithMany(p => p.UserGifts)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserGifts_Users");
        });

        modelBuilder.Entity<Winner>(entity =>
        {
            entity.HasOne(d => d.Gift).WithMany(p => p.Winners)
                .HasForeignKey(d => d.GiftId)
                .HasConstraintName("FK_Winners_Gifts");

            entity.HasOne(d => d.User).WithMany(p => p.Winners)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Winners_Users");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
