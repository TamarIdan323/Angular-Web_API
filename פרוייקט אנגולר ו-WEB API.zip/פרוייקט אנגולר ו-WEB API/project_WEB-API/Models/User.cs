﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models;

public partial class User
{
    public int UserId { get; set; }


    [Required]
    [StringLength(256)]
    public string UserName { get; set; } = null!;


    [Required]
    [StringLength(256)]
    public string UserPassword { get; set; } = null!;

   
    [StringLength(50)]
    public string? Name { get; set; }


    [EmailAddress]
    public string? UserEmail { get; set; }


    [Required]
    [StringLength(50)]
    public string UserAdress { get; set; } = null!;


    [Required]
    [StringLength(50)]
    public string UserPhone { get; set; } = null!;


    [Required]
    [StringLength(50)]
    public string UserRole { get; set; } = null!;

    public virtual ICollection<Basket> Baskets { get; set; } = new List<Basket>();

    public virtual ICollection<UserGift> UserGifts { get; set; } = new List<UserGift>();

    public virtual ICollection<Winner> Winners { get; set; } = new List<Winner>();
}
