﻿namespace project_WEB_API.Models
{
    public class giftsWithWinners
    {

        public string GiftTitle { get; set; } = null!;

        public string? ImageGift { get; set; }

        public List<string> Winners { get; set; } = new List<string>();

    }
}
