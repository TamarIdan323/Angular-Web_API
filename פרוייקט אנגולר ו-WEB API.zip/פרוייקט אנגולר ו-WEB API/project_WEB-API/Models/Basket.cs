﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models;

public partial class Basket
{
    public int Id { get; set; }


    [Required (ErrorMessage = "user id is required")]
    [Range(1, int.MaxValue, ErrorMessage = "user id must be positive number")]
    public int UserId { get; set; }


    [Required(ErrorMessage = "gift id is required")]
    [Range(1, int.MaxValue, ErrorMessage = "gift id must be positive number")]
    public int GiftId { get; set; }

    public virtual Gift Gift { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
