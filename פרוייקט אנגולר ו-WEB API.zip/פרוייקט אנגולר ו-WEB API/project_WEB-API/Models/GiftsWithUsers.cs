﻿using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models
{
    public class GiftsWithUsers
    {
        public int GiftId { get; set; }


        [Required(ErrorMessage = "gift title is required")]
        [StringLength(50)]
        public string GiftTitle { get; set; } = null!;


        [StringLength(50)]
        public string? Description { get; set; }


        [Required]
        public int TicketCost { get; set; }


        [Required]
        public int NumBuyers { get; set; }

        public string? ImageName { get; set; }

        public List<User> GiftUsers { get; set; } = new List<User>();
    }
}
