﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models;

public partial class Donor
{
    public int DonorId { get; set; }


    [Required(ErrorMessage = "donor name is required")]
    [StringLength(50)]
    public string DonorName { get; set; } = null!;


    [Required]
    [StringLength(50)]
    public string DonorPhone { get; set; } = null!;

    [Required]
    [EmailAddress]
    [StringLength(50)]
    public string DonorEmail { get; set; } = null!;

    public virtual ICollection<Gift> Gifts { get; set; } = new List<Gift>();
}
