﻿using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models
{
    public class WinnersWithGifts
    {

        [StringLength(50)]
        public string? Name { get; set; }


        [EmailAddress]
        public string? UserEmail { get; set; }


        [Required]
        [StringLength(50)]
        public string UserAdress { get; set; } = null!;


        [Required]
        [StringLength(50)]
        public string UserPhone { get; set; } = null!;


        [Required(ErrorMessage = "user id is required")]
        [Range(1, int.MaxValue, ErrorMessage = "gift id must be positive number")]
        public int GiftId { get; set; } = 0;


        [Required]
        [StringLength(50)]
        public string GiftTitle { get; set; } = null!;
    }
}
