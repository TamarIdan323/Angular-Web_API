﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_WEB_API.Models;

public partial class Gift
{
    public int GiftId { get; set; }


    [Required(ErrorMessage = "gift title is required")]
    [StringLength(50)]
    public string GiftTitle { get; set; } = null!;


    [StringLength(50)]
    public string? Description { get; set; }


    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "gift donor id must be positive number")]
    public int GiftDonorId { get; set; }


    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "ticket cost must be positive number")]
    public int TicketCost { get; set; }


    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "category id must be positive number")]
    public int CategoryId { get; set; }


    [Required]
    [Range(0, int.MaxValue, ErrorMessage = "num buyers must be positive number")]
    public int NumBuyers { get; set; } = 0;

    public int? ImageGiftId { get; set; }

    public virtual ICollection<Basket> Baskets { get; set; } = new List<Basket>();

    public virtual Category Category { get; set; } = null!;

    public virtual Donor GiftDonor { get; set; } = null!;

    public virtual GiftsImage? ImageGift { get; set; }

    public virtual ICollection<UserGift> UserGifts { get; set; } = new List<UserGift>();

    public virtual ICollection<Winner> Winners { get; set; } = new List<Winner>();
}
