﻿using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public interface IBuyersUsersRepositories
    {
        string BuyGift(int id, string token);

        List<giftsWithDonors> GetAllOrders(string token);
    
    }
}
