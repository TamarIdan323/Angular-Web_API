﻿using Microsoft.EntityFrameworkCore;
using project_WEB_API.Models;
using System.Drawing;

namespace project_WEB_API.Repositories
{
    public class DonorRepositories : IDonorRepositories
    {

        private readonly GiftsDbContext _context;

        public DonorRepositories(GiftsDbContext context)
        {
            _context = context;
        }

        public List<Donor> GetDonors()
        {
            var allDonors = _context.Donors
                .Include(d => d.Gifts)
                .ThenInclude(g => g.ImageGift)
                .ToList();
            return allDonors;
        }

        public Donor GetDonorById(int id)
        {
            Donor? donor = _context.Donors
                .Include(d => d.Gifts)
                .FirstOrDefault(d => d.DonorId == id);
            return donor;
        }

        public List<Donor> GetDonorByName(string name)
        {
            var donor = _context.Donors.Where(d => d.DonorName == name).Include(g => g.Gifts).ThenInclude(i => i.ImageGift).ToList();
            return donor;

        }

        public List<Donor> GetDonorByEmail(string email)
        {
            var donor = _context.Donors.Where(d => d.DonorEmail == email).Include(g => g.Gifts).ThenInclude(i => i.ImageGift).ToList();
            return donor;

        }

        public List<Donor> GetDonorByGiftName(string giftName)
        {
            Gift? gift = _context.Gifts.FirstOrDefault(g => g.GiftTitle == giftName);
            if (gift != null)
            {
                var giftDonorId = gift.GiftDonorId;
                var donor = _context.Donors.Where(d => d.DonorId == giftDonorId).ToList();
                return donor;
            }
            return null;
        }

        public void AddDonor(Donor donor)
        {
            try
            {
                _context.Donors.Add(donor);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateDonor(Donor donor)
        {
            try
            {
                _context.Donors.Update(donor);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void DeleteDonor(int id)
        {
            try
            {
                Donor? donor = _context.Donors.Find(id);
                if (donor.Gifts != null)
                {
                    return;
                }
                else
                {
                    if (donor != null)
                    {
                        var tmpGift = _context.Gifts.Where(g => g.GiftDonorId == donor.DonorId);
                        _context.RemoveRange(tmpGift);
                        _context.Donors.Remove(donor);
                        _context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
    }
}
