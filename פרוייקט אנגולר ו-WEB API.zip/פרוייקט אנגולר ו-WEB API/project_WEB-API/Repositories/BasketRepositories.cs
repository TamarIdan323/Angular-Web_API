﻿using OfficeOpenXml.FormulaParsing.LexicalAnalysis;
using project_WEB_API.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;


namespace project_WEB_API.Repositories
{
    public class BasketRepositories : IBasketRepositories
    {
        private readonly GiftsDbContext _context;

        public BasketRepositories(GiftsDbContext context)
        {
            _context = context;
        }

        public string AddToCart(int id, string token)
        {
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);

                var username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

                if (username == null)
                {
                    throw new UnauthorizedAccessException("Forbidden");
                }

                var user = _context.Users.FirstOrDefault(u => u.UserName == username);

                if (user == null)
                {
                    throw new KeyNotFoundException("user not found");
                }

                var gift = _context.Gifts.FirstOrDefault(g => g.GiftId == id);
                if (gift == null)
                {
                    throw new KeyNotFoundException("gift not found");
                }

                Basket basket = new Basket
                {
                    UserId = user.UserId,
                    GiftId = gift.GiftId
                };

                _context.Baskets.Add(basket);
                _context.SaveChanges();

                return $"Gift {gift.GiftTitle} added to {user.UserName}'s cart.";
            }
            catch (UnauthorizedAccessException ex)
            {
                throw ex;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }
            catch
            {
                return "";
            }


        }

        public List<giftsWithDonors> GetBasket(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jwtToken = handler.ReadJwtToken(token);

            var username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            if (username == null)
            {
                return null;
            }

            var user = _context.Users.FirstOrDefault(u => u.UserName == username);

            if (user == null)
            {
                return null;
            }

            var allBasket = (from b in _context.Baskets
                             where b.UserId == user.UserId
                             join g in _context.Gifts on b.GiftId equals g.GiftId
                             join donor in _context.Donors on g.GiftDonorId equals donor.DonorId
                             join category in _context.Categories on g.CategoryId equals category.CategoryId
                             join image in _context.GiftsImages on g.ImageGiftId equals image.ImageId
                             select new giftsWithDonors
                             {
                                 GiftId = g.GiftId,
                                 GiftTitle = g.GiftTitle,
                                 Description = g.Description,
                                 DonorName = donor.DonorName,
                                 TicketCost = g.TicketCost,
                                 CategoryName = category.CategoryName,
                                 NumBuyers = g.NumBuyers,
                                 ImageGift = image.ImageName,
                             }).ToList();

            return allBasket;

        }

        public string DeleteGiftFromBasket(int id, string token)
        {
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);

                var username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

                if (username == null)
                {
                    throw new UnauthorizedAccessException("Forbidden");
                }

                var user = _context.Users.FirstOrDefault(u => u.UserName == username);

                if (user == null)
                {
                    throw new KeyNotFoundException("user not found");
                }


                var tmpGift = _context.Baskets.FirstOrDefault(g => g.GiftId == id && g.UserId == user.UserId);
                if (tmpGift != null)
                {
                    _context.Baskets.Remove(tmpGift);
                    _context.SaveChanges();

                    return $"gift {id} deleted from basket of user {user.UserName} ";
                }
                return "no such gift";
            }
            catch (UnauthorizedAccessException ex)
            {
                throw ex;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }
            catch
            {
                return "";
            }

        }
    }
}

