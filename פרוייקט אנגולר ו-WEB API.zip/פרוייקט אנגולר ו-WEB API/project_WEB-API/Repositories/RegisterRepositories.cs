﻿using Microsoft.AspNetCore.Identity;
using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public class RegisterRepositories :IRegisterRepositories
    {
        private readonly GiftsDbContext _context;
        private readonly PasswordHasher<User> _passwordHasher;
        public RegisterRepositories(GiftsDbContext context)
        {
            _context = context;
            _passwordHasher = new PasswordHasher<User>();
        }

        public string UserRegister(User user)
        {
            try
            {


                User? tmpUser = _context.Users.FirstOrDefault(u => u.UserName == user.UserName);
                if (tmpUser == null)
                {
                    user.UserPassword = _passwordHasher.HashPassword(user, user.UserPassword);
                    _context.Users.Add(user);
                    _context.SaveChanges();
                    return "user register seccsfuly";
                }
                throw new KeyNotFoundException("somthing went worn, try register again");
            }
            catch (KeyNotFoundException ex) {
                throw ex;
            }

        }
    }
}
