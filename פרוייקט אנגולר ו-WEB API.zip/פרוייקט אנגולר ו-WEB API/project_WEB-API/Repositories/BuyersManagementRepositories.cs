﻿using Microsoft.EntityFrameworkCore;
using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public class BuyersManagementRepositories : IBuyersManagementRepositories
    {
        private readonly GiftsDbContext _context;

        public BuyersManagementRepositories(GiftsDbContext context)
        {
            _context = context;
        }

        public List<User> GetAllTheBuyers(int id)
        {
            var gift = _context.Gifts.FirstOrDefault(g => g.GiftId == id);
            if (gift != null)
            {
                var allTheBuyers = from userGift in _context.UserGifts
                                   where userGift.GiftId == id
                                   join user in _context.Users on userGift.UserId equals user.UserId
                                   select new User
                                   {
                                       UserName = user.UserName,
                                       UserPassword = user.UserPassword,
                                       Name = user.Name,
                                       UserEmail = user.UserEmail,
                                       UserAdress = user.UserAdress,
                                       UserPhone = user.UserPhone,
                                       UserRole = user.UserRole,
                                   };
                return allTheBuyers.ToList();
            }
            return null;
        }

        public List<giftsWithDonors> OrderGiftExpensive_mostBuyers(string orderByOption)
        {
            var result = from userGift in _context.UserGifts
                          join gift in _context.Gifts on userGift.GiftId equals gift.GiftId
                          join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                          join category in _context.Categories on gift.CategoryId equals category.CategoryId
                          join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                          orderby gift.TicketCost
                          select new giftsWithDonors
                          {
                              GiftId = gift.GiftId,
                              GiftTitle = gift.GiftTitle,
                              Description = gift.Description,
                              DonorName = donor.DonorName,
                              TicketCost = gift.TicketCost,
                              CategoryName = category.CategoryName,
                              NumBuyers = gift.NumBuyers,
                              ImageGift = image.ImageName,
                          };
            switch (orderByOption)
            {
                case "mostBuyers":
                    result = result.OrderByDescending(g => g.TicketCost);
                    break;
                case "mostExpensive":
                    result = result.OrderByDescending(g => g.NumBuyers);
                    break;
            }
            return result.ToList();
        }

        public List<User> GetAllBuyers()
        {
            var result = from userGift in _context.UserGifts
                         join user in _context.Users on userGift.UserId equals user.UserId
                         select new User
                         {
                             UserId = user.UserId,
                             UserName = user.UserName,
                             UserPassword = user.UserPassword,
                             Name =user.Name,
                             UserEmail = user.UserEmail,
                             UserAdress = user.UserAdress,
                             UserPhone = user.UserPhone,
                             UserRole = user.UserRole,
                         };
            return result.ToList();
        }

        public List<GiftsWithUsers> GetAllGiftWithBuyers()
        {
            var giftsWithBuyers = _context.Gifts
                .Include(g => g.UserGifts)
                .ThenInclude(ug => ug.User)
                .Include(gift => gift.ImageGift)
                .Select(gift => new GiftsWithUsers
                {
                    GiftId = gift.GiftId,
                    GiftTitle = gift.GiftTitle,
                    Description = gift.Description,
                    TicketCost = gift.TicketCost,
                    NumBuyers = gift.UserGifts.Count,
                    ImageName = gift.ImageGift != null ? gift.ImageGift.ImageName : null,
                    GiftUsers = gift.UserGifts.Select(ug => new User
                    {
                        UserId = ug.User.UserId,
                        UserName = ug.User.UserName,
                        Name = ug.User.Name,
                        UserEmail = ug.User.UserEmail,
                        UserAdress = ug.User.UserAdress,
                        UserPhone = ug.User.UserPhone,
                        UserRole = ug.User.UserRole
                    }).ToList()
                }).ToList();

            return giftsWithBuyers;
        }
    }
}
