﻿using Microsoft.AspNetCore.Identity;
using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public interface ILoginRepositories
    {
        User LoginOfUser(string UserName, string UserPassword);
        bool GetRole(string token);


    }
}
