﻿using project_WEB_API.Models;
namespace project_WEB_API.Repositories
{
    public interface IRegisterRepositories
    {
        string UserRegister(User user); 
    }
}
