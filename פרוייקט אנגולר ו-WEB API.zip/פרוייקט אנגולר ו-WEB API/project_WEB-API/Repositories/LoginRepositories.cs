﻿using Microsoft.AspNetCore.Identity;
using project_WEB_API.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace project_WEB_API.Repositories
{
    public class LoginRepositories : ILoginRepositories
    {
        private readonly GiftsDbContext _context;
        private readonly PasswordHasher<User> _passwordHasher;

        public LoginRepositories(GiftsDbContext context)
        {
            _context = context;
            _passwordHasher = new PasswordHasher<User>();
        }

        public User LoginOfUser(string UserName, string UserPassword)
        {
            try
            {


                User? user = _context.Users.FirstOrDefault(x => x.UserName == UserName);
                if (user == null)
                {
                    throw new KeyNotFoundException("user not found");

                }
                else
                {
                    var s = _passwordHasher.VerifyHashedPassword(user, user.UserPassword, UserPassword) == PasswordVerificationResult.Success;
                    if (s)
                    {
                        return user;
                    }
                }
                return null;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }

        }


        public bool GetRole(string token)
        {
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);

                var userRole = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;

                if (userRole == "Admin")
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
    }
}
