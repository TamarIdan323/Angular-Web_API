﻿using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public interface IDonorRepositories
    {
        List<Donor> GetDonors(); 
        Donor GetDonorById(int id);
        List<Donor> GetDonorByName(string name);
        List<Donor> GetDonorByEmail(string email); 
        List<Donor> GetDonorByGiftName(string giftName);
        void AddDonor(Donor donor);
        void UpdateDonor(Donor donor);
        void DeleteDonor(int id); 
    }
}
