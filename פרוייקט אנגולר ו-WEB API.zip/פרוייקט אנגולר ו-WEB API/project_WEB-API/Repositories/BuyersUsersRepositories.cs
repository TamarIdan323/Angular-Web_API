﻿using OfficeOpenXml.FormulaParsing.LexicalAnalysis;
using project_WEB_API.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace project_WEB_API.Repositories
{
    public class BuyersUsersRepositories : IBuyersUsersRepositories
    {
        private readonly GiftsDbContext _context;

        public BuyersUsersRepositories(GiftsDbContext context)
        {
            _context = context;
        }

        public string BuyGift(int id, string token)
        {
            try
            {

                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);

                var username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

                if (username == null)
                {
                    throw new UnauthorizedAccessException("Forbidden");
                }

                var user = _context.Users.FirstOrDefault(u => u.UserName == username);

                if (user == null)
                {
                    throw new KeyNotFoundException("user not found");
                }

                var gift = _context.Gifts.FirstOrDefault(g => g.GiftId == id);
                if (gift == null)
                {
                    throw new KeyNotFoundException("gift not found");
                }

                UserGift product = new UserGift
                {
                    UserId = user.UserId,
                    GiftId = gift.GiftId
                };
                _context.UserGifts.Add(product);

                var tmpGift = _context.Baskets.FirstOrDefault(g => g.GiftId == id && g.UserId == g.UserId);
                if (tmpGift == null)
                    return "no such gift";
                else
                    _context.Baskets.Remove(tmpGift);


                gift.NumBuyers++;

                _context.Update(gift);

                _context.SaveChanges();

                return $"Gift {gift.GiftTitle} Bought by {user.UserName} ";
            }
            catch (UnauthorizedAccessException ex)
            {
                throw ex;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }
            catch
            {
                return "";
            }
        }



        public List<giftsWithDonors> GetAllOrders(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jwtToken = handler.ReadJwtToken(token);

            var username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            if (username == null)
            {
                return null;
            }

            var user = _context.Users.FirstOrDefault(u => u.UserName == username);

            if (user == null)
            {
                return null;
            }

            var orders = (from u in _context.UserGifts
                          where u.UserId == user.UserId
                          join g in _context.Gifts on u.GiftId equals g.GiftId
                          join donor in _context.Donors on g.GiftDonorId equals donor.DonorId
                          join category in _context.Categories on g.CategoryId equals category.CategoryId
                          join image in _context.GiftsImages on g.ImageGiftId equals image.ImageId
                          select new giftsWithDonors
                          {
                              GiftId = g.GiftId,
                              GiftTitle = g.GiftTitle,
                              Description = g.Description,
                              DonorName = donor.DonorName,
                              TicketCost = g.TicketCost,
                              CategoryName = category.CategoryName,
                              NumBuyers = g.NumBuyers,
                              ImageGift = image.ImageName,
                          }).ToList();
            return orders;
        }

    }
}
