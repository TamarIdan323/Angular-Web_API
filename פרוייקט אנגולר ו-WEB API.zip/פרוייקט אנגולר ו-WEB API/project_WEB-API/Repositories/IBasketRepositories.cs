﻿using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public interface IBasketRepositories
    {
        string AddToCart(int id, string token);

        List<giftsWithDonors> GetBasket(string token);

        string DeleteGiftFromBasket(int id, string token); 
    }
}
