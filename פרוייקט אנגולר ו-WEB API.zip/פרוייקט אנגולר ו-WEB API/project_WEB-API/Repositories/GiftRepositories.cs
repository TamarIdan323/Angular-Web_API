﻿using Microsoft.EntityFrameworkCore;
using project_WEB_API.Models;
using System.Drawing;

namespace project_WEB_API.Repositories
{
    public class GiftRepositories : IGiftRepositories
    {
        private readonly GiftsDbContext _context;

        public GiftRepositories(GiftsDbContext context)
        {
            _context = context;
        }
        public List<giftsWithDonors> GetGifts()
        {
            var giftsWithDonor = from gift in _context.Gifts
                                 join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                                 join category in _context.Categories on gift.CategoryId equals category.CategoryId
                                 join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                                 select new giftsWithDonors
                                 {
                                     GiftId = gift.GiftId,
                                     GiftTitle = gift.GiftTitle,
                                     Description = gift.Description,
                                     DonorName = donor.DonorName,
                                     TicketCost = gift.TicketCost,
                                     CategoryName = category.CategoryName,
                                     NumBuyers = gift.NumBuyers,
                                     ImageGift = image.ImageName,
                                 };
            return giftsWithDonor.ToList();
        }

        public giftsWithDonors GetGiftById(int id)
        {
            var giftById = (from gift in _context.Gifts
                            where gift.GiftId == id
                            join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                            join category in _context.Categories on gift.CategoryId equals category.CategoryId
                            join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                            select new giftsWithDonors
                            {
                                GiftId = gift.GiftId,
                                GiftTitle = gift.GiftTitle,
                                Description = gift.Description,
                                DonorName = donor.DonorName,
                                TicketCost = gift.TicketCost,
                                CategoryName = category.CategoryName,
                                NumBuyers = gift.NumBuyers,
                                ImageGift = image.ImageName,
                            }).FirstOrDefault();
            return giftById;
        }

        public List<giftsWithDonors> GetGiftByTitle(string title)
        {
            var GiftByTitle = (from gift in _context.Gifts
                               where gift.GiftTitle == title
                               join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                               join category in _context.Categories on gift.CategoryId equals category.CategoryId
                               join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                               select new giftsWithDonors
                               {
                                   GiftId = gift.GiftId,
                                   GiftTitle = gift.GiftTitle,
                                   Description = gift.Description,
                                   DonorName = donor.DonorName,
                                   TicketCost = gift.TicketCost,
                                   CategoryName = category.CategoryName,
                                   NumBuyers = gift.NumBuyers,
                                   ImageGift = image.ImageName,
                               }).ToList();
            return GiftByTitle;
        }

        public List<giftsWithDonors> GetGiftByDonor(string tmpDonor)
        {
            var d = _context.Donors.FirstOrDefault(d => d.DonorName == tmpDonor);
            var GiftByDonor = from gift in _context.Gifts
                              where gift.GiftDonorId == d.DonorId
                              join category in _context.Categories on gift.CategoryId equals category.CategoryId
                              join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                              select new giftsWithDonors
                              {
                                  GiftId = gift.GiftId,
                                  GiftTitle = gift.GiftTitle,
                                  Description = gift.Description,
                                  DonorName = d.DonorName,
                                  TicketCost = gift.TicketCost,
                                  CategoryName = category.CategoryName,
                                  NumBuyers = gift.NumBuyers,
                                  ImageGift = image.ImageName,
                              };
            return GiftByDonor.ToList();
        }

        public List<giftsWithDonors> GetGiftByNumBuyers(int numBuyers)
        {
            var GiftnumBuyers = from gift in _context.Gifts
                                where gift.NumBuyers == numBuyers
                                join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                                join category in _context.Categories on gift.CategoryId equals category.CategoryId
                                join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                                select new giftsWithDonors
                                {
                                    GiftId = gift.GiftId,
                                    GiftTitle = gift.GiftTitle,
                                    Description = gift.Description,
                                    DonorName = donor.DonorName,
                                    TicketCost = gift.TicketCost,
                                    CategoryName = category.CategoryName,
                                    NumBuyers = gift.NumBuyers,
                                    ImageGift = image.ImageName,
                                };
            return GiftnumBuyers.ToList();
        }

        public List<string> GetAllCategories()
        {
            var list = from category in _context.Categories
                       select category.CategoryName;

            return list.ToList();
        }

        public List<giftsWithWinners> GetGiftWitWinners()
        {
            var allGifts = _context.Gifts
                .Include(g => g.Winners)
                .ThenInclude(ug => ug.User)
                .Include(gift => gift.ImageGift)
                .Select(gift => new giftsWithWinners
                {
                    GiftTitle = gift.GiftTitle,
                    ImageGift = gift.ImageGift != null ? gift.ImageGift.ImageName : null,
                    Winners = gift.Winners.Select(ug => ug.User.UserName).ToList()
                }).ToList();

            return allGifts;
        }


        public List<giftsWithDonors> OrderGiftByPrice()
        {
            var result = (from gift in _context.Gifts
                          join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                          join category in _context.Categories on gift.CategoryId equals category.CategoryId
                          join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                          orderby gift.TicketCost
                          select new giftsWithDonors
                          {
                              GiftId = gift.GiftId,
                              GiftTitle = gift.GiftTitle,
                              Description = gift.Description,
                              DonorName = donor.DonorName,
                              TicketCost = gift.TicketCost,
                              CategoryName = category.CategoryName,
                              NumBuyers = gift.NumBuyers,
                              ImageGift = image.ImageName,
                          }).ToList();
            return result;
        }

        public List<giftsWithDonors> OrderGiftByCategory()
        {
            var result = (from gift in _context.Gifts
                          join donor in _context.Donors on gift.GiftDonorId equals donor.DonorId
                          join category in _context.Categories on gift.CategoryId equals category.CategoryId
                          join image in _context.GiftsImages on gift.ImageGiftId equals image.ImageId
                          orderby category.CategoryName
                          select new giftsWithDonors
                          {
                              GiftId = gift.GiftId,
                              GiftTitle = gift.GiftTitle,
                              Description = gift.Description,
                              DonorName = donor.DonorName,
                              TicketCost = gift.TicketCost,
                              CategoryName = category.CategoryName,
                              NumBuyers = gift.NumBuyers,
                              ImageGift = image.ImageName,
                          }).ToList();
            return result;
        }


        public void AddGift(giftsWithDonors gift)
        {
            try
            {
                var d = _context.Donors.FirstOrDefault(d => d.DonorName == gift.DonorName);
                var c = _context.Categories.FirstOrDefault(c => c.CategoryName == gift.CategoryName);
                var i = _context.GiftsImages.FirstOrDefault(i => i.ImageName == gift.ImageGift);
                if (d == null)
                {
                    d = _context.Donors.First();
                }
                if (c == null)
                {
                    c = _context.Categories.First();
                }
                if (i == null)
                {
                    i = _context.GiftsImages.First();
                }
                var g = new Gift
                {
                    GiftTitle = gift.GiftTitle,
                    Description = gift.Description,
                    GiftDonorId = d.DonorId,
                    TicketCost = gift.TicketCost,
                    CategoryId = c.CategoryId,
                    NumBuyers = gift.NumBuyers,
                    ImageGiftId = i.ImageId,
                };
                _context.Gifts.Add(g);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateGift(giftsWithDonors gift)
        {
            try
            {
                var d = _context.Donors.FirstOrDefault(d => d.DonorName == gift.DonorName);
                var c = _context.Categories.FirstOrDefault(c => c.CategoryName == gift.CategoryName);
                var i = _context.GiftsImages.FirstOrDefault(i => i.ImageName == gift.ImageGift);
                var tmpGift = _context.Gifts.FirstOrDefault(g => g.GiftId == gift.GiftId);

                tmpGift.GiftId = gift.GiftId;
                tmpGift.GiftTitle = gift.GiftTitle;
                tmpGift.Description = gift.Description;
                tmpGift.GiftDonorId = d.DonorId;
                tmpGift.TicketCost = gift.TicketCost;
                tmpGift.CategoryId = c.CategoryId;
                tmpGift.NumBuyers = gift.NumBuyers;
                tmpGift.ImageGiftId = i.ImageId;
                _context.Update(tmpGift);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteGift(int id)
        {
            try
            {
                var tmpGift = _context.UserGifts.Find(id);
                if (tmpGift != null)
                {
                    return;
                }
                else
                {
                    Gift? gift = _context.Gifts.Find(id);

                    if (gift != null)
                    {
                        _context.Gifts.Remove(gift);
                        _context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




    }
}




