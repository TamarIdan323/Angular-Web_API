﻿using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public interface IRaffleRepositories
    {
        User GetWinner(int id);      
        List<WinnersWithGifts> GetAllWinners();
        void SaveWinnersToExcel();
        void SaveTotalMoneyToExcel(); 
    }
}
