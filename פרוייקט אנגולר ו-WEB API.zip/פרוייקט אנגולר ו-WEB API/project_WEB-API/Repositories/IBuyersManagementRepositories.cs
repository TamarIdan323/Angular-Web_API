﻿using project_WEB_API.Models;

namespace project_WEB_API.Repositories
{
    public interface IBuyersManagementRepositories
    {
        List<User> GetAllTheBuyers(int id);
        List<giftsWithDonors> OrderGiftExpensive_mostBuyers(string orderByOption);
        List<User> GetAllBuyers();
        List<GiftsWithUsers> GetAllGiftWithBuyers();
    }
}
