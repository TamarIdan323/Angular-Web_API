using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using project_WEB_API.Models;
using project_WEB_API.Repositories;
using project_WEB_API.Services;
using Serilog;
using System.Text;
using project_WEB_API.Services;


var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<GiftsDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    options.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
});

builder.Services.AddHttpContextAccessor();

builder.Services.AddScoped<IGiftRepositories, GiftRepositories>();
builder.Services.AddScoped<IGiftServices, GiftServices>();
builder.Services.AddScoped<IDonorRepositories, DonorRepositories>();
builder.Services.AddScoped<IDonorServices, DonorServices>();
builder.Services.AddScoped<IRegisterRepositories, RegisterRepositories>();
builder.Services.AddScoped<IRegisterServices, RegisterServices>();
builder.Services.AddScoped<ILoginRepositories, LoginRepositories>();
builder.Services.AddScoped<ILoginServices, LoginServices>();
builder.Services.AddScoped<IRaffleRepositories, RaffleRepositories>();
builder.Services.AddScoped<IRaffleServices, RaffleServices>();
builder.Services.AddScoped<IBuyersManagementRepositories, BuyersManagementRepositories>();
builder.Services.AddScoped<IBuyersManagementServices, BuyersManagementServices>();
builder.Services.AddScoped<IBasketRepositories, BasketRepositories>();
builder.Services.AddScoped<IBasketServices, BasketServices>();
builder.Services.AddScoped<IBuyersUsersRepositories, BuyersUsersRepositories>();
builder.Services.AddScoped<IBuyersUsersServices, BuyersUsersServices>();

builder.Services.AddScoped<JwtTokenService>();


builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Attachments API",
        Description = "An API to manage attachments",
        Contact = new OpenApiContact
        {
            Name = "Your Name",
            Email = "your.email@example.com",
            Url = new Uri("https://yourwebsite.com"),
        }
    });

    c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Enter 'Bearer {your_token}'"
    });

    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});

builder.Services.AddAuthentication("Bearer")
    .AddJwtBearer(options =>
    {
        var jwtSettings = builder.Configuration.GetSection("JwtSettings");
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtSettings["Issuer"],
            ValidAudience = jwtSettings["Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]))
        };
    });

Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
     .MinimumLevel.Information() 
    .Enrich.FromLogContext()
    .CreateLogger();
builder.Host.UseSerilog();

Log.Information("Application Starting...");

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.WithOrigins("http://localhost:4200") 
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();


if (app.Environment.IsDevelopment())
{

    app.UseDeveloperExceptionPage(); 
}
else
{
    app.UseExceptionHandler("/Home/Error"); 
}


if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();

    app.UseSwagger();

    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Attachments API V1");
        c.RoutePrefix = string.Empty; 
    });
}

app.UseCors("AllowAll");
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.UseAuthorization();

app.MapControllers();

app.Run();