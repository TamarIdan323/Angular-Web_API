﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class DonorsController : ControllerBase
    {
        private readonly IDonorServices _donorsServices;
        public DonorsController(IDonorServices donorService)
        {
            _donorsServices = donorService;
        }

        [HttpGet("getAllDonors")]
        public IActionResult GetAll()
        {
            var donors = _donorsServices.GetDonors();
            if (donors == null)
            {
                return NotFound();
            }
            return Ok(donors);
        }

        [HttpGet("DonorById/{id}")]
        public IActionResult GetDonorById(int id)
        {
            var donor = _donorsServices.GetDonorById(id);
            if (donor == null)
            {
                return NotFound();
            }
            return Ok(donor);
        }

        [HttpGet("DonorByName/{name}")]
        public IActionResult GetDonorByName(string name)
        {
            var donor = _donorsServices.GetDonorByName(name);
            if (donor == null)
            {
                return NotFound();
            }
            return Ok(donor);
        }

        [HttpGet("DonorByEmail/{email}")]
        public IActionResult GetDonorByEmail(string email)
        {
            var donor = _donorsServices.GetDonorByEmail(email);
            if (donor == null)
            {
                return NotFound();
            }
            return Ok(donor);
        }

        [HttpGet("DonorByGiftName/{giftName}")]
        public IActionResult GetDonorByGiftName(string giftName)
        {
            var donor = _donorsServices.GetDonorByGiftName(giftName);
            if (donor == null)
            {
                return NotFound();
            }
            return Ok(donor);
        }

        [HttpPost("createNewDonor")]
        public IActionResult CreateNewDonor(Donor donor)
        {
            try
            {
                _donorsServices.AddDonor(donor);
                return Ok(donor);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }
        }

        [HttpPut("updateDonor")]
        public IActionResult UpdateDonor(Donor donor)
        {
            try
            {
                _donorsServices.UpdateDonor(donor);
                return Ok(donor);
            }

            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }
        }

        [HttpDelete("DeleteDonor/{id}")]
        public IActionResult DeleteDonor(int id)
        {
            try
            {
                _donorsServices.DeleteDonor(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }
        }

    }
}
