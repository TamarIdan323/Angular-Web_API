﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class BuyersManagementController : ControllerBase
    {
        private readonly IBuyersManagementServices _buyersManagementServices;
        public BuyersManagementController(IBuyersManagementServices buyersManagementServices)
        {
            _buyersManagementServices = buyersManagementServices;
        }

        [HttpGet("getAllTheBuyers/{id}")]
        public IActionResult GetAllTheBuyers(int id)
        {
            var buyers = _buyersManagementServices.GetAllTheBuyers(id);
            if (buyers == null)
            {
                return NotFound("no buyers");
            }
            return Ok(buyers);
        }

        [HttpGet("OrderGiftExpensive_mostBuyers/{orderByOption}")]
        public IActionResult OrderGiftExpensive_mostBuyers(string orderByOption)
        {
            var users = _buyersManagementServices.OrderGiftExpensive_mostBuyers(orderByOption);
            if (users == null)
            {
                return NotFound("no user bought in your chines auction gift number {{orderByOption}}");
            }
            return Ok(users);
        }

        [HttpGet("GetAllBuyers")]
        public IActionResult GetAllBuyers()
        {
            var users = _buyersManagementServices.GetAllBuyers();
            if (users == null)
            {
                return NotFound("no user bought in your chines auction");
            }
            return Ok(users);
        }


        [HttpGet("GetAllGiftWithBuyers")]
        public IActionResult GetAllGiftWithBuyers()
        {
            var listOfBuyers = _buyersManagementServices.GetAllGiftWithBuyers();
            if (listOfBuyers == null)
            {
                return NotFound();
            }
            return Ok(listOfBuyers);
        }
    }
}
