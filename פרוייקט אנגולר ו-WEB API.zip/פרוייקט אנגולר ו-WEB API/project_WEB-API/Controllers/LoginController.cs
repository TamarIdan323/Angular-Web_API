﻿using Azure;
using Azure.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

        private readonly ILoginServices _loginServices;
        private readonly JwtTokenService _jwtTokenService;
        public LoginController(ILoginServices loginService, JwtTokenService jwtTokenService)
        {
            _loginServices = loginService;
            _jwtTokenService = jwtTokenService;
        }
        [HttpGet("LoginUser")]
        public IActionResult GetUser(string UserName, string UserPassword)
        {
            try
            {
                var user = _loginServices.LoginOfUser(UserName, UserPassword);
                if (user != null)
                {
                    if (UserName != "Tamar")
                    {
                        var roles = new List<string> { "User" };
                        var token = _jwtTokenService.GenerateJwtToken(UserName, roles);
                        return Ok(new { Token = token });
                    }
                    else
                    {
                        var roles = new List<string> { "Admin" };
                        var token = _jwtTokenService.GenerateJwtToken(UserName, roles);
                        return Ok(new { Token = token });
                    }

                }
                return Unauthorized("Invalid credentials");
            }
            catch (KeyNotFoundException ex)

            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }


        }

        [HttpGet("GetRole")]
        public IActionResult GetRole()
        {
            try
            {
                bool result = _loginServices.GetRole();
                if (result == null)
                {
                    return BadRequest("failed");
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }

        }
    }
}
