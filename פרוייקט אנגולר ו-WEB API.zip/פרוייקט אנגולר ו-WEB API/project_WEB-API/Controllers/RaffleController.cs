﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class RaffleController : ControllerBase
    {
        private readonly IRaffleServices _rafflesServices;
        public RaffleController(IRaffleServices raffleService)
        {
            _rafflesServices = raffleService;
        }

        [HttpGet("getWinner/{id}")]
        public IActionResult GetWinner(int id)
        {
            try
            {
                var user = _rafflesServices.GetWinner(id);
                if (user == null)
                {
                    return NotFound("Something went wrong, try again.");
                }
                return Ok(user);
            }
            catch (KeyNotFoundException ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }
        }

        [HttpGet("GetAllWinners")]
        public IActionResult GetAllWinners()
        {
            var winner = _rafflesServices.GetAllWinners();
            if (winner == null)
            {
                return NotFound("Something went wrong, try again.");
            }
            return Ok(winner);
        }

        [HttpGet("saveWinnersToExcel")]
        public IActionResult SaveWinnersToExcel()
        {
            _rafflesServices.SaveWinnersToExcel();
            return Ok("Winners saved to Excel successfully.");
        }

        [HttpGet("saveTotalMoneyToExcel")]
        public IActionResult SaveTotalMoneyToExcel()
        {
            _rafflesServices.SaveTotalMoneyToExcel();
            return Ok("Total money saved to Excel successfully.");
        }
    }


}
