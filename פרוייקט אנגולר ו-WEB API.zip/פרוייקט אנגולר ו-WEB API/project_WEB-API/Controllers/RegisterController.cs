﻿using Azure;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {

        private readonly IRegisterServices _registerServices;
        public RegisterController(IRegisterServices registerServices)
        {
            _registerServices = registerServices;
        }

        [HttpPost("UserRegister")]
        public IActionResult CreateNewGift(User user)
        {
            try
            {
                string str = _registerServices.UserRegister(user);
                if (str == "user register seccsfuly")
                    return Ok(new { message = str });
                else
                    return Ok("user register not seccsfuly");
            }
            catch (KeyNotFoundException ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }

        }
    }
}
