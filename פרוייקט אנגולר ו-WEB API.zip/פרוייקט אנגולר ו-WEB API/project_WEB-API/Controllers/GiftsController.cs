﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;


namespace project_WEB_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class GiftsController : ControllerBase
    {
        private readonly IGiftServices _giftsServices;
        public GiftsController(IGiftServices giftService)
        {
            _giftsServices = giftService;
        }

        [HttpGet("getAllGifts")]
        public IActionResult GetAll()
        {
            var gifts = _giftsServices.GetGifts();
            return Ok(gifts);
        }
        [Authorize(Roles = "Admin")]
        [HttpGet("giftById/{id}")]
        public IActionResult GetGiftById(int id)
        {
            var gift = _giftsServices.GetGiftById(id);
            if (gift == null)
            {
                return NotFound();
            }
            return Ok(gift);
        }
        [Authorize(Roles = "Admin")]
        [HttpGet("GiftByTitle/{title}")]
        public IActionResult GetGiftByTitle(string title)
        {
            var gift = _giftsServices.GetGiftByTitle(title);
            if (gift == null)
            {
                return NotFound();
            }
            return Ok(gift);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("GiftByDonor/{donor}")]
        public IActionResult GetGiftByDonor(string donor)
        {
            var gift = _giftsServices.GetGiftByDonor(donor);
            if (gift == null)
            {
                return NotFound();
            }
            return Ok(gift);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("GetGiftByNumBuyers/{numBuyers}")]
        public IActionResult GetGiftByNumBuyers(int numBuyers)
        {
            var gift = _giftsServices.GetGiftByNumBuyers(numBuyers);
            if (gift == null)
            {
                return NotFound();
            }
            return Ok(gift);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("GetAllCategories")]
        public IActionResult GetAllCategories()
        {
            var categories = _giftsServices.GetAllCategories();
            return Ok(categories);
        }

        [HttpGet("GetGiftWitWinners")]
        public IActionResult GetGiftWitWinners()
        {
            var gifts = _giftsServices.GetGiftWitWinners();
            return Ok(gifts);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("OrderGiftByPrice")]
        public IActionResult OrderGiftByPrice()
        {
            var allGiftsOrderByPrice = _giftsServices.OrderGiftByPrice();
            if (allGiftsOrderByPrice == null)
            {
                return NotFound();
            }
            return Ok(allGiftsOrderByPrice);
        }
        [Authorize(Roles = "Admin")]
        [HttpGet("OrderGiftByCategory")]
        public IActionResult OrderGiftByCategory()
        {
            var allGiftsOrderByCategory = _giftsServices.OrderGiftByCategory();
            if (allGiftsOrderByCategory == null)
            {
                return NotFound();
            }
            return Ok(allGiftsOrderByCategory);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("createNewGift")]
        public IActionResult CreateNewGift(giftsWithDonors gift)
        {
            try
            {
                _giftsServices.AddGift(gift);

                return Ok(gift);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }

        }


        [Authorize(Roles = "Admin")]
        [HttpPut("updateGift")]
        public IActionResult UpdateGift(giftsWithDonors gift)
        {
            try
            {
                _giftsServices.UpdateGift(gift);
                return Ok(gift);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }

        }


        [Authorize(Roles = "Admin")]
        [HttpDelete("DeleteGift/{id}")]
        public IActionResult DeleteGift(int id)
        {
            try
            {
                _giftsServices.DeleteGift(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }

        }
    }
}
