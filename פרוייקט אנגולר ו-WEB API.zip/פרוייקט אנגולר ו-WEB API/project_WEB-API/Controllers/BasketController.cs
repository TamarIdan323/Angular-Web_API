﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{
    [Authorize(Roles = "User, Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class BasketController : ControllerBase
    {
        private readonly IBasketServices _basketServices;
        public BasketController(IBasketServices basketServices)
        {
            _basketServices = basketServices;
        }


        [HttpGet("GetBasket")]
        public IActionResult GetBasket()
        {
            var basket = _basketServices.GetBasket();
            if (basket == null)
            {
                return NotFound("no basket");
            }
            return Ok(basket);
        }

        [HttpPost("AddToCart/{id}")]
        public IActionResult AddToCart(int id)
        {
            try
            {
                var response = _basketServices.AddToCart(id);
                if (response == null)
                {
                    return BadRequest("failed");
                }
                return Ok(new {message = response});
            }
            catch (UnauthorizedAccessException ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }
            catch (KeyNotFoundException ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }


        }

        [HttpDelete("DeleteGiftFromBasket/{id}")]
        public IActionResult DeleteGiftFromBasket(int id)
        {
            try
            {
                var response = _basketServices.DeleteGiftFromBasket(id);
                if (response == null)
                {
                    return BadRequest("failed");
                }
                return Ok(new { message = response });
            }
            catch (UnauthorizedAccessException ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }
            catch (KeyNotFoundException ex)
            {
                return BadRequest(ex.GetType + " : " + ex.Message);
            }

        }
    }


}
