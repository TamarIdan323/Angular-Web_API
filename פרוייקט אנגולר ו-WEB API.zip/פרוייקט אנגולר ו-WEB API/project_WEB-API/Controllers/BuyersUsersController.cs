﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using project_WEB_API.Models;
using project_WEB_API.Services;

namespace project_WEB_API.Controllers
{
    [Authorize(Roles = "User, Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class BuyersUsersController : ControllerBase
    {
        private readonly IBuyersUsersServices _buyersUsersServices;
        public BuyersUsersController(IBuyersUsersServices buyersUsersServices)
        {
            _buyersUsersServices = buyersUsersServices;
        }

        [HttpPost("BuyGift/{id}")]
        public IActionResult BuyGift(int id)
        {
            try
            {
                var response = _buyersUsersServices.BuyGift(id);
                if (response == null)
                {
                    return BadRequest("failed");
                }

                return Ok(new { message = response });
            }
            catch (UnauthorizedAccessException ex)

            {

                return BadRequest(ex.GetType + " : " + ex.Message);

            }

            catch (KeyNotFoundException ex)

            {

                return BadRequest(ex.GetType + " : " + ex.Message);

            }

        }



        [HttpGet("GetAllOrders")]
        public IActionResult GetAllOrders()
        {
            var order = _buyersUsersServices.GetAllOrders();
            if (order == null)
            {
                return NotFound("no basket");
            }
            return Ok(order);
        }
    }
}
