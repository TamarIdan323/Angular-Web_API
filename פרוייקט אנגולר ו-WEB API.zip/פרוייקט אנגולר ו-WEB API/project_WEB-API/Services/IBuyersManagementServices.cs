﻿using project_WEB_API.Models;

namespace project_WEB_API.Services
{
    public interface IBuyersManagementServices
    {
        List<User> GetAllTheBuyers(int id);
        List<giftsWithDonors> OrderGiftExpensive_mostBuyers(string orderByOption);
        List<User> GetAllBuyers();
        List<GiftsWithUsers> GetAllGiftWithBuyers();
    }
}
