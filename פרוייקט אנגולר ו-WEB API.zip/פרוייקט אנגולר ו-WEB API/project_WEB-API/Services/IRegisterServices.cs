﻿using project_WEB_API.Models;

namespace project_WEB_API.Services
{
    public interface IRegisterServices
    {
        string UserRegister(User user);
    }
}
