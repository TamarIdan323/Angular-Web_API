﻿using project_WEB_API.Models;

namespace project_WEB_API.Services
{
    public interface IBasketServices
    {
        string AddToCart(int id);

        List<giftsWithDonors> GetBasket();

        string DeleteGiftFromBasket(int id);

    }
}
