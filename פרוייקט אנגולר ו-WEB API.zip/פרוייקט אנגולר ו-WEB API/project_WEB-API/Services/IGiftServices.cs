﻿using project_WEB_API.Models;

namespace project_WEB_API.Services
{
    public interface IGiftServices
    {
        List<giftsWithDonors> GetGifts();
        giftsWithDonors GetGiftById(int id);
        List<giftsWithDonors> GetGiftByTitle(string title);
        List<giftsWithDonors> GetGiftByDonor(string donor);
        List<giftsWithDonors> GetGiftByNumBuyers(int numBuyers);
        List<string> GetAllCategories();
        List<giftsWithWinners> GetGiftWitWinners();
        List<giftsWithDonors> OrderGiftByPrice();
        List<giftsWithDonors> OrderGiftByCategory();
        void AddGift(giftsWithDonors gift);
        void UpdateGift(giftsWithDonors gift);
        void DeleteGift(int id);
        
    }
}
