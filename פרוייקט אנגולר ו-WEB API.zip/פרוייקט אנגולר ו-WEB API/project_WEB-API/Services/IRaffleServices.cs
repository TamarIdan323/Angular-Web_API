﻿using project_WEB_API.Models;
using System.Text.Json.Nodes;

namespace project_WEB_API.Services
{
    public interface IRaffleServices
    {
        User GetWinner(int id);

        List<WinnersWithGifts> GetAllWinners();
        void SaveWinnersToExcel();
        void SaveTotalMoneyToExcel();
    }
}
