﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;

namespace project_WEB_API.Services
{
    public class BuyersManagementServices :IBuyersManagementServices
    {
        private readonly IBuyersManagementRepositories _buyersManagementServices;

        public BuyersManagementServices(IBuyersManagementRepositories buyersManagementServices)
        {
            _buyersManagementServices = buyersManagementServices;
        }

        public List<User> GetAllTheBuyers(int id)
        {
            return _buyersManagementServices.GetAllTheBuyers(id);
        }

        public List<giftsWithDonors> OrderGiftExpensive_mostBuyers(string orderByOption)
        {
            return _buyersManagementServices.OrderGiftExpensive_mostBuyers(orderByOption);
        }

        public List<User> GetAllBuyers()
        {
            return _buyersManagementServices.GetAllBuyers();
        }

        public List<GiftsWithUsers> GetAllGiftWithBuyers()
        {
            return _buyersManagementServices.GetAllGiftWithBuyers();
        }
    }
}
