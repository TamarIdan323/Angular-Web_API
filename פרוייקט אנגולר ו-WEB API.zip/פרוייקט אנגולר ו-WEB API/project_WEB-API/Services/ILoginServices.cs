﻿using project_WEB_API.Models;

namespace project_WEB_API.Services
{
    public interface ILoginServices 
    {
        User LoginOfUser(string UserName, string UserPassword);
        bool GetRole();
    }
}
