﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;

namespace project_WEB_API.Services
{
    public class BasketServices : IBasketServices
    {
        private readonly IBasketRepositories _basketServices;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public BasketServices(IBasketRepositories basketServices, IHttpContextAccessor httpContextAccessor)
        {
            _basketServices = basketServices;
            _httpContextAccessor = httpContextAccessor;
        }

        public string AddToCart(int id)
        {
            var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("User token is missing.");
            }
            try
            {
                return _basketServices.AddToCart(id, token);
            }
            catch (Exception ex)
            {
                return "";
            }

        }

        public List<giftsWithDonors> GetBasket()
        {
            var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("User token is missing.");
            }
            return _basketServices.GetBasket(token);
        }

        public string DeleteGiftFromBasket(int id)
        {
            var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("User token is missing.");
            }
            try
            {
                return _basketServices.DeleteGiftFromBasket(id, token);
            }
            catch (Exception ex)
            {
                return "";
            }
        }

    }
}
