﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;

namespace project_WEB_API.Services
{
    public class BuyersUsersServices : IBuyersUsersServices
    {
        private readonly IBuyersUsersRepositories _buyersUsersServices;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public BuyersUsersServices(IBuyersUsersRepositories buyersUsersServices, IHttpContextAccessor httpContextAccessor)
        {
            _buyersUsersServices = buyersUsersServices;
            _httpContextAccessor = httpContextAccessor;
        }

        public string BuyGift(int id)
        {
            var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("User token is missing.");
            }
            try
            {
                return _buyersUsersServices.BuyGift(id, token);
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public List<giftsWithDonors> GetAllOrders()
        {
            var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("User token is missing.");
            }

            return _buyersUsersServices.GetAllOrders(token);
        }

    }
}
