﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;

namespace project_WEB_API.Services
{
    public class RegisterServices : IRegisterServices
    {
        private readonly IRegisterRepositories _registerRepository;
        private readonly ILogger<RegisterServices> _logger;

        public RegisterServices(IRegisterRepositories registerRepository, ILogger<RegisterServices> logger)
        {
            _registerRepository = registerRepository;
            _logger = logger;
        }

        public string UserRegister(User user)
        {
            try
            {
                _logger.LogInformation("user 👉 {user.Name} registered successfully", user.Name);
                return _registerRepository.UserRegister(user);
            }
            catch (Exception ex)
            {
                return "";
            }
        }
    }
}
