﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;
using System.Net.Mail;
using System.Text.Json;
using MailKit.Net.Smtp;
using MimeKit;
using MimeKit.Text;
using System.Runtime.InteropServices;

namespace project_WEB_API.Services
{
    public class RaffleServices : IRaffleServices
    {

        private readonly IRaffleRepositories _raffelRepositoreis;
        private readonly ILogger<RaffleServices> _logger;

        public RaffleServices(IRaffleRepositories raffleRepositories, ILogger<RaffleServices> logger)
        {
            _raffelRepositoreis = raffleRepositories;
            _logger = logger;
        }

        public User GetWinner(int id)
        {
            try
            {
                var user = _raffelRepositoreis.GetWinner(id);
                _logger.LogInformation("Winner 👉 {user.UserName} won gift {id}", user.UserName, id);
                SendEmailToWinner(user, id);
                return user;
            }
            catch (Exception ex)
            {
                return null;
            }


        }

        public List<WinnersWithGifts> GetAllWinners()
        {

            return _raffelRepositoreis.GetAllWinners();
        }

        public void SaveWinnersToExcel()
        {
            _raffelRepositoreis.SaveWinnersToExcel();
        }

        public void SaveTotalMoneyToExcel()
        {
            _raffelRepositoreis.SaveTotalMoneyToExcel();
        }

        private void SendEmailToWinner(User winner, int id)
        {
            try
            {
                using (var smtpClient = new System.Net.Mail.SmtpClient("smtp.office365.com", 587))
                {
                    smtpClient.Credentials = new System.Net.NetworkCredential("38328178744@mby.co.il", "Student@264");
                    smtpClient.EnableSsl = true;

                    var mailMessage = new System.Net.Mail.MailMessage
                    {
                        From = new System.Net.Mail.MailAddress("38328178744@mby.co.il"),
                        Subject = "(נסיון שליחת מייל פרויקט אנגולר) Congratulations! You've won a prize!",
                        Body = $"Dear {winner.Name},\n\n" +
                               $"Congratulations! You have won prize {id} in our raffle.\n\n" +
                               "Please contact us to claim your prize.\n\n" +
                               "Best regards,\nThe Team",
                        IsBodyHtml = false,
                    };
                    Console.WriteLine(winner.UserEmail);
                    mailMessage.To.Add(winner.UserEmail);

                    smtpClient.Send(mailMessage);
                }
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine($"Failed to send email: {ex.Message}");
            }
        }

    }
}
