﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;
using System.Drawing;

namespace project_WEB_API.Services
{
    public class GiftServices : IGiftServices
    {
        private readonly IGiftRepositories _giftsRepository;
        private readonly ILogger<GiftServices> _logger;


        public GiftServices(IGiftRepositories giftsRepository, ILogger<GiftServices> logger)
        {
            _giftsRepository = giftsRepository;
            _logger = logger;
        }

        public List<giftsWithDonors> GetGifts()
        {
            var allGifts = _giftsRepository.GetGifts();
            return allGifts;
        }

        public giftsWithDonors GetGiftById(int id)
        {
            return _giftsRepository.GetGiftById(id);
        }

        public List<giftsWithDonors> GetGiftByTitle(string title)
        {
            return _giftsRepository.GetGiftByTitle(title);
        }

        public List<giftsWithDonors> GetGiftByDonor(string title)
        {
            return _giftsRepository.GetGiftByDonor(title);
        }

        public List<giftsWithDonors> GetGiftByNumBuyers(int numBuyers)
        {
            return _giftsRepository.GetGiftByNumBuyers(numBuyers);
        }

        public List<string> GetAllCategories()
        {
            return _giftsRepository.GetAllCategories();
        }

        public List<giftsWithWinners> GetGiftWitWinners()
        {
            return _giftsRepository.GetGiftWitWinners();
        }

        public List<giftsWithDonors> OrderGiftByPrice()
        {
            return _giftsRepository.OrderGiftByPrice();
        }

        public List<giftsWithDonors> OrderGiftByCategory()
        {
            return _giftsRepository.OrderGiftByCategory();
        }

        public void AddGift(giftsWithDonors gift)
        {
            try
            {
                _giftsRepository.AddGift(gift);
                _logger.LogInformation("gift 👉 {gift.GiftTitle} created successfully", gift.GiftTitle);
            }
            catch (Exception ex)
            {
                return;
            }

        }

        public void UpdateGift(giftsWithDonors gift)
        {
            try
            {
                _giftsRepository.UpdateGift(gift);
                _logger.LogInformation("gift 👉 {gift.GiftTitle} update successfully", gift.GiftTitle);
            }
            catch (Exception ex)
            {
                return;
            }

        }

        public void DeleteGift(int id)
        {
            try
            {
                _giftsRepository.DeleteGift(id);
                _logger.LogInformation("gift id: {id} deleted successfully", id);

            }
            catch (Exception ex)
            {
                return;
            }

        }

    }
}
