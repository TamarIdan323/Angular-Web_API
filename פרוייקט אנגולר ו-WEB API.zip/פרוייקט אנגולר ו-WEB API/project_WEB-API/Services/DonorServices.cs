﻿using Microsoft.EntityFrameworkCore;
using project_WEB_API.Models;
using project_WEB_API.Repositories;
using System.Drawing;

namespace project_WEB_API.Services
{
    public class DonorServices : IDonorServices
    {
        private readonly IDonorRepositories _donorsRepository;
        private readonly ILogger<DonorServices> _logger;

        public DonorServices(IDonorRepositories donorsRepository, ILogger<DonorServices> logger)
        {
            _donorsRepository = donorsRepository;
            _logger = logger;
        }

        public List<Donor> GetDonors()
        {
            var allDonors = _donorsRepository.GetDonors();
            return allDonors;
        }

        public Donor GetDonorById(int id)
        {
            return _donorsRepository.GetDonorById(id);
        }

        public List<Donor> GetDonorByName(string name)
        {
            var donors = _donorsRepository.GetDonorByName(name);
            return donors;
        }

        public List<Donor> GetDonorByEmail(string email)
        {
            var donors = _donorsRepository.GetDonorByEmail(email);
            return donors;
        }

        public List<Donor> GetDonorByGiftName(string giftName)
        {
            var donors = _donorsRepository.GetDonorByGiftName(giftName);
            return donors;
        }

        public void AddDonor(Donor donor)
        {
            try
            {
                _donorsRepository.AddDonor(donor);
                _logger.LogInformation("Donor 👉 {donor.DonorName} created successfully", donor.DonorName);

            }
            catch (Exception ex)
            {
                return;
            }

        }

        public void UpdateDonor(Donor donor)
        {
            try
            {
                _donorsRepository.UpdateDonor(donor);
                _logger.LogInformation("Donor 👉 {donor.DonorName} updated successfully", donor.DonorName);
            }
            catch (Exception ex)
            {
                return;
            }

        }

        public void DeleteDonor(int id)
        {
            try
            {
                _donorsRepository.DeleteDonor(id);
                _logger.LogInformation("Donor id: {id} deleted successfully", id);

            }
            catch (Exception ex)
            {
                return;
            }

        }
    }
}
