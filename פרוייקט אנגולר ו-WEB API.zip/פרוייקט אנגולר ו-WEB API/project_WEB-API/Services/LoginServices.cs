﻿using project_WEB_API.Models;
using project_WEB_API.Repositories;

namespace project_WEB_API.Services
{
    public class LoginServices : ILoginServices
    {
        private readonly ILoginRepositories _loginRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LoginServices(ILoginRepositories loginRepository, IHttpContextAccessor httpContextAccessor)
        {
            _loginRepository = loginRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        public User LoginOfUser(string UserName, string UserPassword)
        {
            try
            {
                return _loginRepository.LoginOfUser(UserName, UserPassword);
            }
            catch (Exception ex)
            {
                return null;
            }


        }

        public bool GetRole()
        {
            var token = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("User token is missing.");
            }
            try
            {
                return _loginRepository.GetRole(token);
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching role: " + ex.Message, ex);

            }

        }
    }
}
