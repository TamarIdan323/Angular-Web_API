import { Component, inject } from '@angular/core';
import { Gift } from '../../models/gift.model';
import { ShoppingCartServiceService } from '../../services/shopping-cart-service.service';
import { BuyersServiceService } from '../../services/buyers-service.service';
import { BuyersUsersServiceService } from '../../services/buyers-users-service.service';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrl: './shopping-cart.component.css',
  providers: [MessageService, ConfirmationService],
})
export class ShoppingCartComponent {

  shoppingCartService: ShoppingCartServiceService = inject(ShoppingCartServiceService);

  buyersUserService: BuyersUsersServiceService = inject(BuyersUsersServiceService);


  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }

  basket: Gift[] = [];

  ordersDialog: boolean = false;
  res: any

  ngOnInit() {
    this.getAllBasket();
  }

  getAllBasket() {
    this.shoppingCartService.GetBasket().subscribe(
      (b) => {
        this.basket = b;
      },
      (error) => {

      }
    );
  }

  delete(id: number) {
    this.shoppingCartService.delete(id).subscribe({
      next: (response) => {
        this.res = response;
        this.messageService.add({severity: 'success', summary: 'success', detail: `${this.res.message}`, life: 3000 });
        this.getAllBasket();
      },
      error: (err) => {
        this.res = err;
        this.messageService.add({severity: 'error', summary: 'error', detail: `${this.res.message}`, life: 3000 });
      }
    })
  }

  buy(id: number) {
    const tmpraffleWasDone = localStorage.getItem('raffleWasDone')
    if (tmpraffleWasDone == 'yes') {
      this.messageService.add({  severity: 'Contrast', summary: 'Error', detail: "The lottery has started No more gifts can be bought", life: 3000  });
    }
    else {
      this.ordersDialog = true;
      this.buyersUserService.BuyGift(id).subscribe({
        next: (response) => {
          this.res = response;
            this.getAllBasket();
          },
            error: (err) => {
              this.res = err;
              this.messageService.add({severity: 'error', summary: 'error', detail: `${this.res.message}`, life: 3000 });
              console.log("failed buying")
            },
      });

    }

  }


  hideDialog() {
    this.ordersDialog=false;
    this.messageService.add({severity: 'success', summary: 'success', detail: `${this.res.message}`, life: 3000 });
  }

}
