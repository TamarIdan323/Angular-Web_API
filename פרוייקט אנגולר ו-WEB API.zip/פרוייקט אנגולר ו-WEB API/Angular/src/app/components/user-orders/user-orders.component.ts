import { Component, inject } from '@angular/core';
import { BuyersUsersServiceService } from '../../services/buyers-users-service.service';
import { Gift } from '../../models/gift.model';

@Component({
  selector: 'app-user-orders',
  templateUrl: './user-orders.component.html',
  styleUrl: './user-orders.component.css'
})
export class UserOrdersComponent {

  buyersUserService: BuyersUsersServiceService = inject(BuyersUsersServiceService);

  constructor() { }

  orders: Gift[]=[];

  ngOnInit() {
    this.buyersUserService.GetAllOrders().subscribe(
      (o) => {
        this.orders = o;
      },
      (error) => {
       
      }
    );
  }





}
