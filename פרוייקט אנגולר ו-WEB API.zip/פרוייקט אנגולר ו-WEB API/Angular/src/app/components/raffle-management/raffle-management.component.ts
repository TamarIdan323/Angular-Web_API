import { Component, inject } from '@angular/core';
import { Gift } from '../../models/gift.model';
import { Observable } from 'rxjs';
import { GiftServiceService } from '../../services/gift-service.service';
import { User } from '../../models/user.model';
import { RaffleServiceService } from '../../services/raffle-service.service';
import { winnersWithGifts } from '../../models/winnersWithGifts';
import * as XLSX from 'xlsx';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-raffle-management',
  templateUrl: './raffle-management.component.html',
  styleUrl: './raffle-management.component.css',
  providers: [MessageService, ConfirmationService],
})
export class RaffleManagementComponent {

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }
  giftService: GiftServiceService = inject(GiftServiceService);

  raffleService: RaffleServiceService = inject(RaffleServiceService);

  gifts: Gift[] = [];

  winners: winnersWithGifts[] = [];

  gifts$: Observable<Gift[]> = this.giftService.getAll();

  ngOnInit() {
    this.giftService.getAll().subscribe({
      next: (g) => {
        this.gifts = g;
        this.getAllWinners();      },
      error: (err) => {
        console.log("failed to get gifts");
      }     
    })
  }

  generateRaffle(id: number) {
    this.raffleService.GetWinner(id).subscribe({
      next: (g) => {
        this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Congratulations!!!! An email has been sent to the lucky winner 👍', life: 3000 });
        this.getAllWinners();
      },
      error: (err) => {
        this.messageService.add({ severity: 'error', summary: 'error', detail: "there is no orders for this gift", life: 3000 });
      }
    })
    localStorage.setItem('raffleWasDone', "yes");
  }

  getAllWinners() {
    this.raffleService.GetAllWinners().subscribe({
      next: (w) => {
        this.winners = w;
      },
      error: (err) => {
        console.log("failed to loed all winners");
      }
    })
  }

  downloadWinnersExcel() {
    const data = this.winners.map(winner => ({
      'giftId': winner.giftId,
      'giftTitle': winner.giftTitle,
      'name': winner.name,
      'userEmail': winner.userEmail,
      'userAdress': winner.userAdress,
      'userPhone': winner.userPhone,
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data, { header: ['giftId', 'giftTitle', 'name', 'userEmail', 'userAdress', 'userPhone'] });

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Winners');

    XLSX.writeFile(wb, 'Winners.xlsx');
  }


  downloadProfitsExcel() {
    const data = this.gifts.map(gift => ({
      'Gift Name': gift.giftTitle,
      'Profit': gift.ticketCost * gift.numBuyers
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data, { header: ['Gift Name', 'Profit'] });

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Winners and Profits');

    XLSX.writeFile(wb, 'Winners_And_Profits.xlsx');
  }

}
