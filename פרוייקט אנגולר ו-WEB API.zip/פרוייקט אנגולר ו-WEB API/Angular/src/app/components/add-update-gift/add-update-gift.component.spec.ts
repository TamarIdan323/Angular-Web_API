import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateGiftComponent } from './add-update-gift.component';

describe('AddUpdateGiftComponent', () => {
  let component: AddUpdateGiftComponent;
  let fixture: ComponentFixture<AddUpdateGiftComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddUpdateGiftComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddUpdateGiftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
