import { Component, inject } from '@angular/core';
import { Gift } from '../../models/gift.model';
import { GiftServiceService } from '../../services/gift-service.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DonorServiceService } from '../../services/donor-service.service';
import { Donor } from '../../models/donor.model';

@Component({
  selector: 'app-add-update-gift',
  templateUrl: './add-update-gift.component.html',
  styleUrl: './add-update-gift.component.css',
  providers: [MessageService, ConfirmationService],
})
export class AddUpdateGiftComponent {

  giftService: GiftServiceService = inject(GiftServiceService);

  donorService: DonorServiceService = inject(DonorServiceService);

  router: Router = inject(Router);

  activatedRoute: ActivatedRoute = inject(ActivatedRoute)

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService, private route: ActivatedRoute) { }

  giftDialog: boolean = false;

  submitted: boolean = false;

  gift: Gift = new Gift() || null;

  giftId: number | null = null;

  allDonors: string[] = [];

  allCategories: string[] = [];

  gifts: Gift[] = [];

  gifts$: Observable<Gift[]> = this.giftService.getAll();

  tmpsubmitted: boolean = false;

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.giftId = +params['id'];
      if (this.giftId && this.giftId != 0) {
        this.loedGift(this.giftId);
      }
    });

    this.donorService.getAll().subscribe({
      next: (d) => {
        this.allDonors = d.map((donor) => donor.donorName);
      },
      error: (err) => {

      }
    });

    this.giftService.GetAllCategories().subscribe({
      next: (c) => {
        this.allCategories = c;
      },
      error: (err) => {

      }
    });
    this.openNew();
  }


  loedGift(id: number) {
    const giftFromService = this.giftService.getById(id).subscribe({
      next: (id) => {
        if (giftFromService) {
          this.gift = id;
        }
      },
      error: (err) => {
        console.log("failed to loed gift");
      }
    });
  }

  openNew() {
    this.submitted = false;
    this.giftDialog = true;
  }

  saveGift() {
    this.tmpsubmitted=true;
      if (this.gift.giftTitle.length > 1 && this.gift.ticketCost > 4) {
        if (this.gift.giftId) {
          this.giftService.update(this.gift).subscribe({
            next: () => {
              this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Gift Updated succefuly', life: 3000 });
            },
            error: (err) => {
              this.messageService.add({ severity: 'error', summary: 'Successful', detail: 'error updating gift', life: 3000 });
            }
          })
        }
        else {
          this.gift.imageGift = 'product-placeholder.svg';
          this.giftService.add(this.gift).subscribe({
            next: () => {
              this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Gift Created', life: 3000 });
            },
            error: (err) => {
              console.log("failed to save gift");
            }
          })
        }
        this.gift = new Gift();
        this.hideDialog();
    }
    
  }

  hideDialog() {
    this.giftDialog = false;
    this.submitted = false;
    this.giftId = null;
    this.router.navigate(['managmentGifts']);
  }

  
  // onImageSelected(event: any) {
  //   const file = event.target.files[0];
  //   if (file) {
  //     const reader = new FileReader();
  //     reader.onload = (e: any) => {
  //       console.log(event);
        
  //       this.gift.imageGift = e.target.result; // שמירת התמונה שנבחרה ב-gift.image
  //     // console.log(this.gift.imageGift);
      
  //     };
  //    reader.readAsDataURL(file); // קורא את התמונה וממיר אותה ל-Base64
  //   }
  // } 

}
