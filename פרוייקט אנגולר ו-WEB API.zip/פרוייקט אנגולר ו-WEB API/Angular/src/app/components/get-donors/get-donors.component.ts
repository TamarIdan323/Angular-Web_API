import { Component, inject } from '@angular/core';
import { Donor } from '../../models/donor.model';
import { DonorServiceService } from '../../services/donor-service.service';
import { Observable } from 'rxjs';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import * as XLSX from 'xlsx';
import { Gift } from '../../models/gift.model';
import { GiftServiceService } from '../../services/gift-service.service';

@Component({
  selector: 'app-get-donors',
  templateUrl: './get-donors.component.html',
  providers: [MessageService, ConfirmationService],
  styleUrl: './get-donors.component.css'
})
export class GetDonorsComponent {

  donorService: DonorServiceService = inject(DonorServiceService);

  giftService: GiftServiceService = inject(GiftServiceService);

  router: Router = inject(Router);

  activatedRoute: ActivatedRoute = inject(ActivatedRoute);

  donors: Donor[] = [];

  gifts: Gift[] = [];

  donor: Donor = new Donor();

  gift: Gift = new Gift();

  tmpDonorName: string = '';

  tmpDonorEmail: string = '';

  tmpGift: string = '';

  showPopup: boolean = false;

  popupMessage: string = '';

  donors$: Observable<Donor[]> = this.donorService.getAll();

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }

  ngOnInit() {
    this.donorService.getAll().subscribe({
      next: (d) => {
        this.donors = d;
      },
      error: (err) => {

      }
    })
    this.giftService.getAll().subscribe({
      next: (g) => {
        this.gifts = g;
      },
      error: (err) => {

      }
    })

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd && event.urlAfterRedirects === '/managmentDonors') {
        this.popupMessage = 'Data saved successfully!';
        this.showPopup = true;
      }
    });
  }

  closePopup() {
    this.showPopup = false;
    window.location.reload();
  }

  onDonorNameChange(event: string) {
    this.tmpDonorName = event;
    if (!this.tmpDonorName.trim()) {
      this.refreshSearch();
    }
    else {
      this.donors = this.donors.filter(donor =>
        donor.donorName.toLowerCase().includes(this.tmpDonorName.toLowerCase())
      );
    }
  }

  onDonorEmailChange(event: string) {
    this.tmpDonorEmail = event;
    if (!this.tmpDonorEmail.trim()) {
      this.refreshSearch();
    }
    else {
      this.donors = this.donors.filter(donor =>
        donor.donorEmail.toLowerCase().includes(this.tmpDonorEmail.toLowerCase())
      );
    }
  }

  onGiftTitleChange(event: string) {
    this.tmpGift = event;
    if (!this.tmpGift.trim()) {
      this.refreshSearch();
    }
    else {
      this.donors = this.donors.filter(donor =>
        donor.gifts.some(gift =>
          gift.giftTitle.toLowerCase().includes(this.tmpGift.toLowerCase())
        )
      );
    }
  }

  refreshSearch() {
    this.donorService.getAll().subscribe({
      next: (g) => {
        this.donors = g;
      },
      error: (err) => {
        console.log("failed to loed donors");
      }
    })
    this.gift = new Gift();
    this.donor = new Donor()
    this.tmpDonorName = '';
    this.tmpDonorEmail = '';
    this.tmpGift = '';
  }

  editDonor(id: number): void {
    this.router.navigate(['managmentDonors/edit', id], { relativeTo: this.activatedRoute.parent });
  }

  openNew() {
    this.router.navigate(['managmentDonors/edit/0'], { relativeTo: this.activatedRoute.parent });
  }

  deleteDonor(d: Donor) {
    this.donorService.delete(d.donorId).subscribe({
      next: () => {
        this.messageService.add({ severity: 'success', summary: 'Successful', detail:  "donor deleted succefuly side note if donor wosent deleted this donor hase gifts and we will lose all the gifts", life: 3000 });
        console.log("donor deleted")
        this.loadDonors();
      },
      error: (err) => {
        console.log("failed to delet donor");
      }
    });

  }


  loadDonors() {
    this.donorService.getAll().subscribe({
      next: (d) => {
        this.donors = d;
      },
      error: (err) => {
        console.log("failed to loed donor");
      }
    })
  }

  downloadDonorsExcel() {
    const data = this.donors.map(donor => ({
      'donorName': donor.donorName,
      'donorPhone': donor.donorPhone,
      'donorEmail': donor.donorEmail
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data, { header: ['donorName', 'donorPhone', 'donorEmail'] });

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Donors');

    XLSX.writeFile(wb, 'Donors.xlsx');
  }
}
