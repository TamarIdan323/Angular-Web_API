import { Component, inject } from '@angular/core';
import { User } from '../../models/user.model';
import { RegisterServiceService } from '../../services/register-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
  providers: [MessageService, ConfirmationService],
})
export class RegisterComponent {

  registerService: RegisterServiceService = inject(RegisterServiceService);

  router: Router = inject(Router);

  activatedRoute: ActivatedRoute = inject(ActivatedRoute);

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }

  userName: string='';

  password: string='';

  Email: string='';

  Adress: string='';

  Phone: string='';

  response : string='';

  user : User= new User();
  isSubmitted: boolean = false;
  register(){
    this.isSubmitted = true;
    this.user.userName=this.userName;
    this.user.name=this.userName;
    this.user.userPassword=this.password;
    this.user.userEmail=this.Email;
    this.user.userAdress=this.Adress;
    this.user.userPhone=this.Phone;
    this.user.userRole="user";
    
    if(this.user.userName.length > 1 && this.password.length > 5 && this.user.userAdress.length > 4 && this.user.userPhone.length > 6 && this.user.userEmail){
      this.registerService.Register(this.user).subscribe({
        next: (s) => {
          console.log(s);
          this.response=s
          this.router.navigate(['login'] , {relativeTo: this.activatedRoute.parent});
        },
        error: (err) => {
          this.messageService.add({severity: 'error', summary: 'error', detail: "error registering", life: 3000 });
        }
      })
    }
      
  }
  // isValidEmail(email: string): boolean {
  //   const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  //   return emailRegex.test(email);
  // }
}
