import { Component, inject } from '@angular/core';
import { GiftServiceService } from '../../services/gift-service.service';
import { ShoppingCartServiceService } from '../../services/shopping-cart-service.service';
import { Gift } from '../../models/gift.model';
import { ConfirmationService, MessageService } from 'primeng/api';
import { RaffleServiceService } from '../../services/raffle-service.service';
import { giftWithWinner } from '../../models/giftWithWinner.model';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-gifts',
  templateUrl: './gifts.component.html',
  styleUrl: './gifts.component.css',
  providers: [MessageService, ConfirmationService],
})
export class GiftsComponent {

  giftService: GiftServiceService = inject(GiftServiceService);

  shoppingCartService: ShoppingCartServiceService = inject(ShoppingCartServiceService);

  raffleService: RaffleServiceService = inject(RaffleServiceService);

  router: Router = inject(Router);

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }

  gifts: Gift[] = [];

  giftsWithWinners: giftWithWinner[] = [];

  flag: boolean = false;

  showPopup: boolean = false;

  popupMessage: string = '';
  res:any

  optionSort = [
    { label: 'price', value: 'price' },
    { label: 'category', value: 'category' }
  ];

  userOptionSort: string = '';

  responsiveOptions = [
    {
      breakpoint: '1024px', 
      numVisible: 3, 
      numScroll: 1
    },
    {
      breakpoint: '768px', 
      numVisible: 2,
      numScroll: 1
    },
    {
      breakpoint: '560px', 
      numVisible: 1, 
      numScroll: 1
    }
  ];

  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd && event.urlAfterRedirects === '/gifts') {
        window.location.reload();
      }
    });
    const raffleWasDone = localStorage.getItem('raffleWasDone');
    if (raffleWasDone == "yes") {
      this.flag = true;
      this.giftService.GetGiftWitWinners().subscribe({
        next: (gw) => {
          this.giftsWithWinners = gw;
        },
        error: (err) => {
          console.log("failed to loed winners");
        }
      })
    }
    this.giftService.getAll().subscribe({
      next: (g) => {
        this.gifts = g;
      },
      error: (err) => {
        console.log("failed to get gifts");
      }
    })
  }

  AddToCart(id: number) {
    const tmpToken = localStorage.getItem('userToken')
    if(tmpToken==''){
      this.messageService.add({ severity: 'error', summary: 'Successful', detail: "You are not registered in the system.", life: 3000 });
    }
    else{
      this.shoppingCartService.add(id).subscribe({
        next: (response) => { 
          console.log(response);
            
          this.res=response;
          this.messageService.add({ severity: 'success', summary: 'Successful', detail: `${this.res.message}`, life: 3000 });
        },
        error: (err) => {
          this.res=err;
          this.messageService.add({ severity: 'error', summary: 'Successful', detail: `${this.res.message}`, life: 3000 });
        }
      })
    } 
  }

  sortGifts() {
    switch (this.userOptionSort) {
      case "price":
        this.gifts.sort((a, b) => b.ticketCost - a.ticketCost);
        break;
      case "category":
        this.gifts.sort((a, b) => a.categoryName.localeCompare(b.categoryName));
        break;
    }
  }
}
