import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Get_delete_giftComponent } from './get_delete_gift.component';

describe('Get_delete_giftComponent', () => {
  let component: Get_delete_giftComponent;
  let fixture: ComponentFixture<Get_delete_giftComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Get_delete_giftComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Get_delete_giftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
