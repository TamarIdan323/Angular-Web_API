import { Component, inject } from '@angular/core';
import { Gift } from '../../models/gift.model';
import { GiftServiceService } from '../../services/gift-service.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Observable} from 'rxjs';
import * as XLSX from 'xlsx';
import { Donor } from '../../models/donor.model';
import { DonorServiceService } from '../../services/donor-service.service';
@Component({
  selector: 'app-get_delete_gift',
  templateUrl: './get_delete_gift.component.html',
  styleUrl: './get_delete_gift.component.css',
  providers: [MessageService, ConfirmationService],
  styles: [
    `:host ::ng-deep .p-dialog .product-image {
          width: 150px;
          margin: 0 auto 2rem auto;
          display: block;
      }`
  ]
})

export class Get_delete_giftComponent {

  giftService: GiftServiceService = inject(GiftServiceService);

  router: Router = inject(Router);

  activatedRoute: ActivatedRoute = inject(ActivatedRoute);

  donorService: DonorServiceService = inject(DonorServiceService);

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }

  giftDialog: boolean = false;

  selectedGifts: Gift[] = [];

  submitted: boolean = false;

  allDonors: Donor[] = [];

  gifts: Gift[] = [];

  donor: Donor = new Donor()

  tmpDonorName: string = '';

  gift: Gift = new Gift();

  tmpGiftName: string = '';

  tmpNumBuyers: number = 0;

  showPopup: boolean = false;

  popupMessage: string = '';

  gifts$: Observable<Gift[]> = this.giftService.getAll();

  res:any

  ngOnInit() {
    this.giftService.getAll().subscribe({
      next: (g) => {
        this.gifts = g;
      },
      error: (err) => {
        
      }
    })

    this.donorService.getAll().subscribe({
      next: (d) => {
        this.allDonors = d;
      },
      error: (err) => {
        
      }
    });

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd && event.urlAfterRedirects === '/managmentGifts') {
        this.popupMessage = 'Data saved successfully!';
        this.showPopup = true;
      }
    });
  }
  closePopup() {
    this.showPopup = false;
    window.location.reload();
  }

  onDonorNameChange(event: string) {
    this.tmpDonorName = event;
    if (!this.tmpDonorName.trim()) {
      this.refreshSearch();
    }
    else {
      this.gifts = this.gifts.filter(gift =>
        gift.donorName.toLowerCase().includes(this.tmpDonorName.toLowerCase())
      );
    }
  }

  ongiftNameChange(event: string) {
    this.tmpGiftName = event;
    if (!this.tmpGiftName.trim()) {
      this.refreshSearch();
    }
    else {
      this.gifts = this.gifts.filter(gift =>
        gift.giftTitle.toLowerCase().includes(this.tmpGiftName.toLowerCase())
      );
    }
  }

  onNumBuyersChange(event: number) {
    this.tmpNumBuyers = event;
    if (!this.tmpNumBuyers) {
      this.refreshSearch();
    }
    else {
      this.giftService.GetGiftByNumBuyers(this.tmpNumBuyers).subscribe({
        next: (tmpgift) => {
          this.gifts = tmpgift;
        },
        error: (err) => {
          console.log("failed to get numBuyers");
        }
      })
    }
  }

  refreshSearch() {
    this.giftService.getAll().subscribe({
      next: (g) => {
        this.gifts = g;
      },
      error: (err) => {
        console.log("failed to get gifts");
      }
    })
    this.gift = new Gift();
    this.donor = new Donor()
    this.tmpDonorName = '';
    this.tmpGiftName = '';
    this.tmpNumBuyers = 0;
  }


  openNew() {
    this.router.navigate(['managmentGifts/edit/0'], { relativeTo: this.activatedRoute.parent });
  }

  deleteSelectedGifts() {
    for (let i = 0; i < this.selectedGifts.length; i++) {
      this.giftService.delete(this.selectedGifts[i].giftId).subscribe({
        next: () => {
          this.messageService.add({ severity: 'success', summary: 'Successful', detail:  "gifts deleted succefuly", life: 3000 });
          this.loadGifts();
        },
        error: () => {
          this.messageService.add({ severity: 'error', summary: 'Successful', detail: "error deleting gifts", life: 3000 });
        }
      });
      this.selectedGifts = [];

    }
  }

  editGift(id: number): void {
    this.router.navigate(['managmentGifts/edit', id], { relativeTo: this.activatedRoute.parent });
  }

  deleteGift(g: Gift) {
    this.giftService.delete(g.giftId).subscribe({
      next: () => {
        this.messageService.add({ severity: 'success', summary: 'Successful', detail:  "gift deleted succefuly side note if gift wosent deleted this gift whas bought by sum users", life: 3000 });
        this.loadGifts();
      },
      error: (err) => {
        this.messageService.add({ severity: 'error', summary: 'error', detail: "this order whas bought by sum users", life: 3000 });
      },
    });
  }


  loadGifts() {
    this.giftService.getAll().subscribe({
      next: (g) => {
        this.gifts = g;
      },
      error: (err) => {
        console.log("failed to loed gifts");
      }
    })
  }

  downloadGiftsExcel() {
    const data = this.gifts.map(gift => ({
      'giftId': gift.giftId,
      'giftTitle': gift.giftTitle,
      'description': gift.description,
      'donorName': gift.donorName,
      'ticketCost': gift.ticketCost,
      'categoryName': gift.categoryName,
      'numBuyers': gift.numBuyers,
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data, { header: ['giftId', 'giftTitle', 'description', 'donorName', 'ticketCost', 'categoryName', 'numBuyers'] });

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Gifts');

    XLSX.writeFile(wb, 'Gifts.xlsx');
  }
}

