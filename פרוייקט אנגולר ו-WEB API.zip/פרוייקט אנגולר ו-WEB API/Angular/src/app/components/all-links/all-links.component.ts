import { Component, inject } from '@angular/core';
import { LoginServiceService } from '../../services/login-service.service';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-all-links',
  templateUrl: './all-links.component.html',
  styleUrl: './all-links.component.css',
  providers: [MessageService, ConfirmationService],
})
export class AllLinksComponent {

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }
  loginService: LoginServiceService = inject(LoginServiceService);
  router: Router = inject(Router);
  isAdmin: boolean = false;

  ngOnInit() {
    const token = localStorage.getItem('userToken');
    if (token == "") {
      return;
    }
    else {
      this.loginService.GetRole().subscribe({
        next: (a) => {
          this.isAdmin = a;
        },
        error: (err) => {

        }
      });
    }
  }

  logOut() {
    localStorage.setItem('userToken', '');
    setTimeout(() => {
      this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'You have logged out successfully', life: 3000 });
      setTimeout(() => {
        this.router.navigate(['gifts']);
      }, 500)

    }, 1000)
    
  }


}
