import { Component, inject } from '@angular/core';
import { LoginServiceService } from '../../services/login-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginService: LoginServiceService = inject(LoginServiceService);

  router: Router = inject(Router);

  userName: string = '';

  password: string = '';

  response: string = '';

  isSubmitted: boolean = false;

  login() {
    this.isSubmitted = true;
    this.loginService.Login(this.userName, this.password).subscribe((response: { token: string }) => {
      const token = response.token; 
      localStorage.setItem('userToken', token);
      this.router.navigate(['/gifts']);
    }, error => {
      console.log("Login failed: username or password are incorent");
    });
  }
}
