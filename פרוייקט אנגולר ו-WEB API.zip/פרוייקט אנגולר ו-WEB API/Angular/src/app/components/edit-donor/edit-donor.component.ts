import { Component, inject } from '@angular/core';
import { DonorServiceService } from '../../services/donor-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Donor } from '../../models/donor.model';
import { donorWithGiftId } from '../../models/donorWithGiftId.model';

@Component({
  selector: 'app-edit-donor',
  templateUrl: './edit-donor.component.html',
  styleUrl: './edit-donor.component.css'
})
export class EditDonorComponent {

  donorService: DonorServiceService = inject(DonorServiceService);

  router: Router = inject(Router);

  activatedRoute: ActivatedRoute = inject(ActivatedRoute)

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService, private route: ActivatedRoute) { }

  donorDialog: boolean = false;

  submitted: boolean = false;

  tmpsubmitted: boolean = false;


  donor: Donor = new Donor() || null;

  donorId: number | null = null;

  tmpDonor: donorWithGiftId = new donorWithGiftId();

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.donorId = +params['id'];
      if (this.donorId && this.donorId != 0) {
        this.loedDonor(this.donorId);
      }
    });
    this.openNew();
  }

  loedDonor(id: number) {
    const donorFromService = this.donorService.GetDonorById(id).subscribe({
      next: (id) => {
        if (donorFromService)
          this.donor = id;
      },
      error: (err) => {

      }
    });
  }

  openNew() {
    this.submitted = false;
    this.donorDialog = true;
  }

  saveDonor() {
this.tmpsubmitted=true;
    if (this.donor.donorName.length > 1 && this.donor.donorPhone.length > 9 && this.donor.donorEmail) {
      if (this.donor.donorName.trim()) {
        if (this.donor.donorId) {
          this.tmpDonor.donorId = this.donor.donorId;
          this.tmpDonor.donorName = this.donor.donorName;
          this.tmpDonor.donorEmail = this.donor.donorEmail;
          this.tmpDonor.donorPhone = this.donor.donorPhone;
          this.donorService.update(this.tmpDonor).subscribe({
            next: () => {

              this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Donor Updated', life: 3000 });
            },
            error: (err) => {
              console.error("Error occurred during update:", err);
              console.log("failed to update donor");
            }
          });
        }
        else {
          this.donor.gifts = [];
          this.donorService.add(this.donor).subscribe({
            next: () => {
              this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Donor Created', life: 3000 });
            },
            error: (err) => {
              console.log("failed to saved donor");
            }
          });

        }
        this.donor = new Donor();
        this.hideDialog();
      }
    }

  }
  hideDialog() {
    this.donorDialog = false;
    this.submitted = false;
    this.donorId = null;
    this.router.navigate(['managmentDonors']);
  }

  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
}
