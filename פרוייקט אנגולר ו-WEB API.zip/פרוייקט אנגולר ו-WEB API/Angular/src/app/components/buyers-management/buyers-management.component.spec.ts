import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyersManagementComponent } from './buyers-management.component';

describe('BuyersManagementComponent', () => {
  let component: BuyersManagementComponent;
  let fixture: ComponentFixture<BuyersManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BuyersManagementComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuyersManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
