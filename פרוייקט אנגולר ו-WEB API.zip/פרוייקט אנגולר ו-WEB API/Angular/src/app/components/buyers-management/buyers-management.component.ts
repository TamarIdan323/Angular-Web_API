import { Component, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ConfirmationService, MessageService } from 'primeng/api';
import { giftsWithUsers } from '../../models/giftsWithUsers';
import { BuyersServiceService } from '../../services/buyers-service.service';

@Component({
  selector: 'app-buyers-management',
  templateUrl: './buyers-management.component.html',
  providers: [MessageService, ConfirmationService],
  styleUrl: './buyers-management.component.css'
})
export class BuyersManagementComponent {

  buyersService: BuyersServiceService = inject(BuyersServiceService);

  optionSort = [
    { label: 'mostExpensive', value: 'mostExpensive' },
    { label: 'mostBuyers', value: 'mostBuyers' }
  ];

  userOptionSort: string = '';

  gifts: giftsWithUsers[] = [];

  buyers$: Observable<giftsWithUsers[]> = this.buyersService.GetAllGiftWithBuyers();

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService) { }

  ngOnInit() {
    this.buyersService.GetAllGiftWithBuyers().subscribe({
      next: (g) => {
        this.gifts = g;
        
      },
      error: (err) => {
      }
    })
  }

  sortGifts() {
    switch (this.userOptionSort) {
      case "mostBuyers":
        this.gifts.sort((a, b) => b.numBuyers - a.numBuyers);
        break;
      case "mostExpensive":
        this.gifts.sort((a, b) => b.ticketCost - a.ticketCost);
        break;
    }

  }

}

