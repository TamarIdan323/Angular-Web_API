import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Get_delete_giftComponent } from './components/get_delete_gift/get_delete_gift.component'
import {NoopAnimationsModule} from '@angular/platform-browser/animations'
import {ImportsModule} from './imports';
import { AddUpdateGiftComponent } from './components/add-update-gift/add-update-gift.component';
import { GetDonorsComponent } from './components/get-donors/get-donors.component';
import { EditDonorComponent } from './components/edit-donor/edit-donor.component';
import { AllLinksComponent } from './components/all-links/all-links.component';
import { BuyersManagementComponent } from './components/buyers-management/buyers-management.component';
import { RaffleManagementComponent } from './components/raffle-management/raffle-management.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { GiftsComponent } from './components/gifts/gifts.component';
import { UserOrdersComponent } from './components/user-orders/user-orders.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { AboutUsComponent } from './components/about-us/about-us.component';

@NgModule({
  declarations: [
    AppComponent,
    Get_delete_giftComponent,
    AddUpdateGiftComponent,
    GetDonorsComponent,
    EditDonorComponent,
    AllLinksComponent,
    BuyersManagementComponent,
    RaffleManagementComponent,
    ShoppingCartComponent,
    RegisterComponent,
    LoginComponent,
    GiftsComponent,
    UserOrdersComponent,
    AboutUsComponent
  ],
  imports: [    
    BrowserModule,
    AppRoutingModule,
    NoopAnimationsModule,
    ImportsModule,
    ConfirmDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
