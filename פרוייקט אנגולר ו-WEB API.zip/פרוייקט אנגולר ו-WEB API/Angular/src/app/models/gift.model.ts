
export class Gift{
    giftId: number=0;
    giftTitle: string='';  
    description?:string; 
    donorName: string='';
    ticketCost: number=0; 
    categoryName:string='';
    numBuyers: number = 0; 
    imageGift?:string;
}