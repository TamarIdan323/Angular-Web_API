import { Gift } from "./gift.model";

export class Donor{
    donorId: number=0;
    donorName: string=''; 
    donorPhone:string=''; 
    donorEmail: string='';
    gifts: Gift[]=[];
}
