export class User{
    userId: number=0; 
    userName: string=''; 
    userPassword?:string; 
    name?: string='';
    userEmail?: string=''; 
    userAdress:string='';
    userPhone: string = ''; 
    userRole?:string;
}