export class donorWithGiftId{
    donorId: number=0;
    donorName: string=''; 
    donorPhone:string=''; 
    donorEmail: string='';
}