export class giftWithWinner{
    giftTitle: string='';  
    imageGift?:string;
    winners: string[]=[];
}