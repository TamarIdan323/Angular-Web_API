export class winnersWithGifts{
    name?: string='';
    userEmail?: string=''; 
    userAdress:string='';
    userPhone: string = ''; 
    giftId: number=0;
    giftTitle: string='';  
}