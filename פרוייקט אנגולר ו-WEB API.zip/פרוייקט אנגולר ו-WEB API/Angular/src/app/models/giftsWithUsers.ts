import { User } from "./user.model";

export class giftsWithUsers{
    giftId: number=0; 
    giftTitle: string='';  
    description?:string; 
    ticketCost: number=0; 
    numBuyers: number = 0; 
    imageGift?:string;
    giftusers: User[]=[];
}