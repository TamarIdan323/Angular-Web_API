import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUpdateGiftComponent } from './components/add-update-gift/add-update-gift.component';
import { Get_delete_giftComponent } from './components/get_delete_gift/get_delete_gift.component';
import { GetDonorsComponent } from './components/get-donors/get-donors.component';
import { EditDonorComponent } from './components/edit-donor/edit-donor.component';
import { AllLinksComponent } from './components/all-links/all-links.component';
import { BuyersManagementComponent } from './components/buyers-management/buyers-management.component';
import { RaffleManagementComponent } from './components/raffle-management/raffle-management.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { GiftsComponent } from './components/gifts/gifts.component';
import { UserOrdersComponent } from './components/user-orders/user-orders.component';

const routes: Routes = [
  { path: '', component: GiftsComponent },
  { path: 'managmentGifts', component: Get_delete_giftComponent, children: [
    { path: 'edit/:id', component: AddUpdateGiftComponent }
  ]},
  { path: 'managmentDonors', component: GetDonorsComponent, children: [
    { path: 'edit/:id', component: EditDonorComponent }
  ]},
  { path: 'managmentBuyers', component: BuyersManagementComponent },
  { path: 'managmentRaffle', component: RaffleManagementComponent },
  { path: 'shoppingCart', component: ShoppingCartComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'gifts', component: GiftsComponent },
  { path: 'orders', component: UserOrdersComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
