import { TestBed } from '@angular/core/testing';

import { BuyersServiceService } from './buyers-service.service';

describe('BuyersServiceService', () => {
  let service: BuyersServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BuyersServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
