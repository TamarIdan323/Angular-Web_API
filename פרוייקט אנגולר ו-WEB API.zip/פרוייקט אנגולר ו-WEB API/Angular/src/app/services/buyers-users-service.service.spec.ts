import { TestBed } from '@angular/core/testing';

import { BuyersUsersServiceService } from './buyers-users-service.service';

describe('BuyersUsersServiceService', () => {
  let service: BuyersUsersServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BuyersUsersServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
