import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { User } from '../models/user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegisterServiceService {

  BASE_URL = 'http://localhost:5030/api/Register';

  http: HttpClient = inject(HttpClient); 
  
  constructor() { }

  Register(u: User): Observable<string> {
    return this.http.post<string>(this.BASE_URL + '/UserRegister', u);
  }
}
