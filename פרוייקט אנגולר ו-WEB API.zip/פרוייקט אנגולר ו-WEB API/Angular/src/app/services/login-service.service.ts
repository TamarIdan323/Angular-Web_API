import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  BASE_URL = 'http://localhost:5030/api/Login';

  http: HttpClient = inject(HttpClient);

  constructor() { }

  Login(userName: string, userPassword: string): Observable<{ token: string }> {
    return this.http.get<{ token: string }>(`${this.BASE_URL}/LoginUser?UserName=${userName}&UserPassword=${userPassword}`);
}

GetRole():Observable<boolean>{
  const token = localStorage.getItem('userToken');   
  const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
  return this.http.get<boolean>(this.BASE_URL + '/GetRole', { headers });
}

}
