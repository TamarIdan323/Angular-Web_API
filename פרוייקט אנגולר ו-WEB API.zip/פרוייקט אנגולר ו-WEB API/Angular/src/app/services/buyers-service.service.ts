import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { giftsWithUsers } from '../models/giftsWithUsers';

@Injectable({
  providedIn: 'root'
})
export class BuyersServiceService {

  BASE_URL = 'http://localhost:5030/api/BuyersManagement';

  http: HttpClient = inject(HttpClient);

  constructor() { }

  lodeToken(){
      const token = localStorage.getItem('userToken');   
      const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
      return headers;
  }

  GetBuyersByGiftId(id: number): Observable<User> {
    const headers = this.lodeToken();
    return this.http.get<User>(this.BASE_URL + '/getAllTheBuyers/' + id, { headers });
  }

  OrderGiftExpensive_mostBuyers(orderByOption: string): Observable<User[]> {
    const headers = this.lodeToken();
    return this.http.get<User[]>(this.BASE_URL + "/OrderGiftExpensive_mostBuyers/" + orderByOption, { headers });
  }

  getAll(): Observable<User[]> {
    const headers = this.lodeToken();
    return this.http.get<User[]>(this.BASE_URL + '/GetAllBuyers', { headers });
  }

  GetAllGiftWithBuyers(): Observable<giftsWithUsers[]> {
    const headers = this.lodeToken();
    return this.http.get<giftsWithUsers[]>(this.BASE_URL + '/GetAllGiftWithBuyers', { headers });
  }
}
