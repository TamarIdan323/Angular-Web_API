import { Injectable, inject } from '@angular/core';
import { Gift } from '../models/gift.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { giftWithWinner } from '../models/giftWithWinner.model';

@Injectable({
  providedIn: 'root'
})
export class GiftServiceService {

  BASE_URL = 'http://localhost:5030/api/Gifts';

  http: HttpClient = inject(HttpClient);

  constructor() { }
  
  lodeToken(){
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return headers;
}
  
  getAll(): Observable<Gift[]> {
    return this.http.get<Gift[]>(this.BASE_URL + '/getAllGifts');
  }

  getById(id: number): Observable<Gift> {
    const headers = this.lodeToken();
    return this.http.get<Gift>(this.BASE_URL + '/giftById/' + id, { headers });
  }

  GetGiftByTitle(str: string): Observable<Gift[]> {
    const headers = this.lodeToken();
    return this.http.get<Gift[]>(this.BASE_URL + "/GiftByTitle/" + str, { headers });
  }

  GetGiftByDonor(str: string): Observable<Gift[]> {
    const headers = this.lodeToken();
    return this.http.get<Gift[]>(this.BASE_URL + "/GiftByDonor/" + str, { headers });
  }

  GetGiftByNumBuyers(num: number): Observable<Gift[]> {
    const headers = this.lodeToken();
    return this.http.get<Gift[]>(this.BASE_URL + "/GetGiftByNumBuyers/" + num, { headers });
  }

  GetAllCategories(): Observable<string[]> {
    const headers = this.lodeToken();
    return this.http.get<string[]>(this.BASE_URL + '/GetAllCategories', { headers });
  }

  GetGiftWitWinners(): Observable<giftWithWinner[]> {
    return this.http.get<giftWithWinner[]>(this.BASE_URL + '/GetGiftWitWinners');
  }

  OrderGiftByPrice(): Observable<Gift[]> {
    const headers = this.lodeToken();
    return this.http.get<Gift[]>(this.BASE_URL + '/OrderGiftByPrice', { headers });
  }

  OrderGiftByCategory(): Observable<Gift[]> {
    const headers = this.lodeToken();
    return this.http.get<Gift[]>(this.BASE_URL + '/OrderGiftByCategory', { headers });
  }

  add(g: Gift): Observable<Gift> {
    const headers = this.lodeToken();
    return this.http.post<Gift>(this.BASE_URL + '/createNewGift', g, { headers });
  }

  update(g: Gift){
    const headers = this.lodeToken();
    return this.http.put(this.BASE_URL +'/updateGift', g, { headers });
  }

  delete(id: number) {
    const headers = this.lodeToken();
    return this.http.delete(this.BASE_URL + '/DeleteGift/' + id, { headers });
  }

}



