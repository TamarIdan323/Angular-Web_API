import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Donor } from '../models/donor.model';
import { donorWithGiftId } from '../models/donorWithGiftId.model';

@Injectable({
  providedIn: 'root'
})
export class DonorServiceService {

  BASE_URL = 'http://localhost:5030/api/Donors';

  http: HttpClient = inject(HttpClient);

  constructor() { }

  lodeToken(){
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return headers;
}

  getAll(): Observable<Donor[]> {
    const headers = this.lodeToken();
    return this.http.get<Donor[]>(this.BASE_URL + '/getAllDonors', { headers });
  }

  GetDonorById(id: number): Observable<Donor> {
    const headers = this.lodeToken();
    return this.http.get<Donor>(this.BASE_URL + '/DonorById/' + id, { headers });
  }

  GetDonorByName(name: string): Observable<Donor[]> {
    const headers = this.lodeToken();
    return this.http.get<Donor[]>(this.BASE_URL + "/DonorByName/" + name, { headers });
  }

  GetDonorByEmail(email: string): Observable<Donor[]> {
    const headers = this.lodeToken();
    return this.http.get<Donor[]>(this.BASE_URL + "/DonorByEmail/" + email, { headers });
  }

  GetDonorByGiftName(giftName: string): Observable<Donor[]> {
    const headers = this.lodeToken();
    return this.http.get<Donor[]>(this.BASE_URL + "/DonorByGiftName/" + giftName, { headers });
  }

  add(donor: Donor): Observable<Donor> {
    const headers = this.lodeToken();
    return this.http.post<Donor>(this.BASE_URL + '/createNewDonor', donor, { headers });
  }

  update(donor: donorWithGiftId): Observable<string> {
    const headers = this.lodeToken();
    return this.http.put<string>(this.BASE_URL +'/updateDonor', donor, { headers });
  }

  delete(id: number): Observable<string> {
    const headers = this.lodeToken();
    return this.http.delete<string>(this.BASE_URL + '/DeleteDonor/' + id, { headers });
  }
}
