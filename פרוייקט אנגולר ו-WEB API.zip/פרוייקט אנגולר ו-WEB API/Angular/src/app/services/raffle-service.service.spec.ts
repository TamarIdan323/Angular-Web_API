import { TestBed } from '@angular/core/testing';

import { RaffleServiceService } from './raffle-service.service';

describe('RaffleServiceService', () => {
  let service: RaffleServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RaffleServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
