import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gift } from '../models/gift.model';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartServiceService {

  BASE_URL = 'http://localhost:5030/api/Basket';

  http: HttpClient = inject(HttpClient);

  constructor() { }

  GetBasket(): Observable<Gift[]> {
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get<Gift[]>(this.BASE_URL + '/GetBasket', { headers });
  }
  

  add(id: number): Observable<string> {
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post<string>(this.BASE_URL + '/AddToCart/' + id, {}, { headers });
  }

  delete(id: number) {
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.delete(this.BASE_URL + '/DeleteGiftFromBasket/' + id, { headers });
  }
}
