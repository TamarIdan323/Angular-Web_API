import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Gift } from '../models/gift.model';

@Injectable({
  providedIn: 'root'
})
export class BuyersUsersServiceService {

  BASE_URL = 'http://localhost:5030/api/BuyersUsers';

  http: HttpClient = inject(HttpClient);

  constructor() { }

  BuyGift(id: number): Observable<string> {
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post<string>(this.BASE_URL + '/BuyGift/' + id, {}, { headers });
  }

  GetAllOrders(): Observable<Gift[]> {
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get<Gift[]>(this.BASE_URL + '/GetAllOrders', { headers });
  }
}
