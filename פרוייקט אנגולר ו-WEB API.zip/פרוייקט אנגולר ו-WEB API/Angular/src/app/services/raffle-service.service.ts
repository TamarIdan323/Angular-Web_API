import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { winnersWithGifts } from '../models/winnersWithGifts';

@Injectable({
  providedIn: 'root'
})
export class RaffleServiceService {

  BASE_URL = 'http://localhost:5030/api/Raffle';

  http: HttpClient = inject(HttpClient);

  constructor() { }

  lodeToken(){
    const token = localStorage.getItem('userToken');   
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return headers;
}

  GetWinner(id: number): Observable<User> {
    const headers = this.lodeToken();
    return this.http.get<User>(this.BASE_URL + '/getWinner/' + id, { headers });
  }

  GetAllWinners(): Observable<winnersWithGifts[]> {
    const headers = this.lodeToken();
    return this.http.get<winnersWithGifts[]>(this.BASE_URL + '/GetAllWinners', { headers });
  }

}
