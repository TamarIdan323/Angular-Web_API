import {
  Tooltip,
  TooltipModule
} from "./chunk-3D4CGHXH.js";
import "./chunk-M4VYGO3K.js";
import "./chunk-NVWVTKUH.js";
import "./chunk-4VBMWFH7.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
