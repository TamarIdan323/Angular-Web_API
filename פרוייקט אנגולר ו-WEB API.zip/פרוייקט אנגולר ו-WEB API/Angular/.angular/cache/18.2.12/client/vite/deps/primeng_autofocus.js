import {
  AutoFocus,
  AutoFocusModule
} from "./chunk-NV347Z5T.js";
import "./chunk-4VBMWFH7.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  AutoFocus,
  AutoFocusModule
};
//# sourceMappingURL=primeng_autofocus.js.map
