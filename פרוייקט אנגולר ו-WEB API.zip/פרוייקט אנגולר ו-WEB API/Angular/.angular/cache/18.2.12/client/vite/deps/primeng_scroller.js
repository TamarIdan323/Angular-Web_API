import {
  Scroller,
  ScrollerModule
} from "./chunk-GO3NQC6K.js";
import "./chunk-BNOJNWF5.js";
import "./chunk-L2SABUG2.js";
import "./chunk-M4VYGO3K.js";
import "./chunk-NVWVTKUH.js";
import "./chunk-4VBMWFH7.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  Scroller,
  ScrollerModule
};
//# sourceMappingURL=primeng_scroller.js.map
