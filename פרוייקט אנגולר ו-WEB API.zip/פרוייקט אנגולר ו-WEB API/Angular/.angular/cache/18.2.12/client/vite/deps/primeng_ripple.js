import {
  Ripple,
  RippleModule
} from "./chunk-4ISVY4EN.js";
import "./chunk-M4VYGO3K.js";
import "./chunk-NVWVTKUH.js";
import "./chunk-4VBMWFH7.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
