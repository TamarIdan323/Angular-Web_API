import {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
} from "./chunk-V2ZL4PFO.js";
import "./chunk-4ISVY4EN.js";
import "./chunk-NV347Z5T.js";
import "./chunk-IFC34UMB.js";
import "./chunk-M4VYGO3K.js";
import "./chunk-NVWVTKUH.js";
import "./chunk-4VBMWFH7.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
};
//# sourceMappingURL=primeng_selectbutton.js.map
