import {
  ProgressBar,
  ProgressBarModule
} from "./chunk-DEZ4U4UX.js";
import "./chunk-M4VYGO3K.js";
import "./chunk-NVWVTKUH.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  ProgressBar,
  ProgressBarModule
};
//# sourceMappingURL=primeng_progressbar.js.map
