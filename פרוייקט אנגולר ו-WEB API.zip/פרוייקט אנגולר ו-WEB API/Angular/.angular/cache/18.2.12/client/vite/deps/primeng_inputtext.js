import {
  InputText,
  InputTextModule
} from "./chunk-CEC53MPK.js";
import "./chunk-IFC34UMB.js";
import "./chunk-M4VYGO3K.js";
import "./chunk-NVWVTKUH.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
