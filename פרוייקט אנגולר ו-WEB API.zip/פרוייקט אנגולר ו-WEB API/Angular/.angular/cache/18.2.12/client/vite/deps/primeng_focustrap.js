import {
  FocusTrap,
  FocusTrapModule
} from "./chunk-LCG24YN2.js";
import "./chunk-4VBMWFH7.js";
import "./chunk-24OLDFJI.js";
import "./chunk-GLDXQWTJ.js";
import "./chunk-4MWRP73S.js";
export {
  FocusTrap,
  FocusTrapModule
};
//# sourceMappingURL=primeng_focustrap.js.map
